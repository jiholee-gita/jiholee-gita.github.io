﻿using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Specialized;
using System.Reflection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace INTERFACE_TESTER
{
    public partial class MainForm : Form
    {
        // Global Variables
		public static string _userId = string.Empty;
        public static string _deviceId = string.Empty;
        public static string _authKey = string.Empty;
		public static string _localhost = string.Empty;
		public static string _stagehost = string.Empty;
		public static string _prodhost = string.Empty;

		// Environement Variables
		public static string _endpointURL = string.Empty;
        public static string _endpointHost = string.Empty;
		public static string _successReturnCode = string.Empty;
        
		public static string _targetIO = string.Empty;
		public static string _targetType = string.Empty;
		public static string _requestType = string.Empty;
		public static string _requestData = string.Empty;
		public static string _uploadFile = string.Empty;
		public static string _responseType = string.Empty;
		public static string _templateJSON = string.Empty;
        public static string _templateText = string.Empty;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainFormLoad(object sender, EventArgs e)
        {
			// Initialize global variable from app.config
            _localhost = System.Configuration.ConfigurationManager.AppSettings["LOCALHOST"];
		    _stagehost = System.Configuration.ConfigurationManager.AppSettings["STAGEHOST"];
		    _prodhost = System.Configuration.ConfigurationManager.AppSettings["PRODHOST"];

            // Store global variable default values
			_endpointHost = _stagehost;
			_targetIO = "INCOMING"; // INCOMING, OUTGOING
			_targetType = "STAGE"; // LOCAL, STAGE, PROD
			_successReturnCode = "0000"; // Success Return Code: "0" or "0000"
            
            // Input text from global variable values
            textBoxURLHost.Text = _endpointHost;
            textBoxUserId.Text = _userId;
            textBoxDeviceId.Text = _deviceId;
            textBoxAuthKey.Text = _authKey;

            // Load data from default values to start
			SetInterfaceTreeView(_targetIO, _targetType);
			textBoxURLHost.Text = _endpointHost;
			inputRequestTabAfterEncrypted.DocumentText = interface_tester.SetHtmlHeaderFooter();
            outputResponseTabBeforeDecrypted.DocumentText = interface_tester.SetHtmlHeaderFooter();
            buttonTapRequestBeforeEncrypted_Click(sender, e);
            buttonTabResponseAfterDecrypted_Click(sender, e);
		}

		#region Event Functions

		#region Interface Type

		private void buttonTabIncoming_Click(object sender, EventArgs e)
		{
			SetInterfaceTreeView("INCOMING", _targetType);
            panelInterfaceTabIncoming.BringToFront();
            buttonTabIncoming.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            buttonTabIncoming.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
			buttonTabOutgoing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
			buttonTabOutgoing.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
			textBoxURLHost.Text = _endpointHost;
            tableLayoutPanelIncomingURLHost.Visible = true;
		}

		private void buttonTabOutgoing_Click(object sender, EventArgs e)
		{
			SetInterfaceTreeView("OUTGOING", _targetType);
            panelInterfaceTabOutgoing.BringToFront();
			buttonTabIncoming.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
			buttonTabIncoming.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            buttonTabOutgoing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            buttonTabOutgoing.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
			tableLayoutPanelIncomingURLHost.Visible = false;
		}

		private void buttonTabIncomingLocal_Click(object sender, EventArgs e)
		{
			SetInterfaceType("INCOMING", "LOCAL");
            buttonTabIncomingLocal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            buttonTabIncomingLocal.ForeColor = System.Drawing.Color.Silver;
			buttonTabIncomingStage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			buttonTabIncomingStage.ForeColor = System.Drawing.Color.Gray;
			buttonTabIncomingProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			buttonTabIncomingProd.ForeColor = System.Drawing.Color.Gray;
			_endpointHost = _localhost;
			textBoxURLHost.Text = _endpointHost;
		}

		private void buttonTabIncomingStage_Click(object sender, EventArgs e)
		{
			SetInterfaceType("INCOMING", "STAGE");
            buttonTabIncomingLocal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            buttonTabIncomingLocal.ForeColor = System.Drawing.Color.Gray;
			buttonTabIncomingStage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			buttonTabIncomingStage.ForeColor = System.Drawing.Color.Silver;
			buttonTabIncomingProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			buttonTabIncomingProd.ForeColor = System.Drawing.Color.Gray;
			_endpointHost = _stagehost;
			textBoxURLHost.Text = _endpointHost;
		}

		private void buttonTabIncomingProd_Click(object sender, EventArgs e)
		{
			SetInterfaceType("INCOMING", "PROD");
            buttonTabIncomingLocal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            buttonTabIncomingLocal.ForeColor = System.Drawing.Color.Gray;
			buttonTabIncomingStage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			buttonTabIncomingStage.ForeColor = System.Drawing.Color.Gray;
			buttonTabIncomingProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			buttonTabIncomingProd.ForeColor = System.Drawing.Color.Silver;
			_endpointHost = _prodhost;
			textBoxURLHost.Text = _endpointHost;
		}

		private void buttonTabOutgoingStage_Click(object sender, EventArgs e)
		{
			SetInterfaceType("OUTGOING", "STAGE");
            buttonTabOutgoingStage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			buttonTabOutgoingStage.ForeColor = System.Drawing.Color.Silver;
			buttonTabOutgoingProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			buttonTabOutgoingProd.ForeColor = System.Drawing.Color.Gray;
		}

		private void buttonTabOutgoingProd_Click(object sender, EventArgs e)
		{
			SetInterfaceType("OUTGOING", "PROD");
            buttonTabOutgoingStage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
			buttonTabOutgoingStage.ForeColor = System.Drawing.Color.Gray;
			buttonTabOutgoingProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			buttonTabOutgoingProd.ForeColor = System.Drawing.Color.Silver;
		}

		#endregion
		
		#region Interface List

		private void buttonUpdateURLHost_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(textBoxURLHost.Text))
            {
                MessageBox.Show("Please enter Endpoint Host URL", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = textBoxURLHost;
            }
            else if (!interface_tester.IsValidUrl(textBoxURLHost.Text))
            {
                MessageBox.Show("Incorrect URL format", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = textBoxURLHost;
            }
            else
            {
                // Update Endpoint HOST URL
                _endpointHost = textBoxURLHost.Text; 
			
                if (_targetIO == "INCOMING")
                {
                    if (_targetType == "LOCAL")
                    {
                        _localhost = textBoxURLHost.Text;
                    }
                    else if (_targetType == "STAGE")
                    {
                        _stagehost = textBoxURLHost.Text;
                    }
                    else if (_targetType == "PROD")
                    {
                        _prodhost = textBoxURLHost.Text;
                    }
                }
            }
		}

        private void interfaceTreeViewNode_Click(object sender, TreeNodeMouseClickEventArgs e)
        {
            string requestsJson = string.Empty;
            string requestInput = string.Empty;

            inputRequestTabSample.Text = string.Empty;
             
            if (e.Node.Parent != null)
            {
                requestsJson = interface_tester.GetJsonFromFile("template.json");
                JObject objRequests = JObject.Parse(requestsJson);
                dynamic dynamicJson = JsonConvert.DeserializeObject(objRequests[_targetIO].ToString());

                foreach (var itemParent in dynamicJson)
                {
					if (itemParent.Name == e.Node.Parent.Text)
                    {
						foreach (var itemChildren in itemParent.Value)
						{
                            if (itemChildren.Name == e.Node.Text)
                            {
                                foreach (var item in itemChildren.Value)
                                {
                                    if (item.Name == "ENDPOINT")
                                    {
                                        foreach (var target in item.Value)
                                        {
                                            if (target.Name == _targetType)
                                            {
												_requestData = e.Node.Text;
                                                _endpointURL = target.Value.ToString().Replace("(($" + _targetType + "HOST))", _endpointHost);
												textBoxEndpoint.Text = _endpointURL;
                                            }
                                        }
                                    }
                                    else if (item.Name == "REQ_TYPE")
                                    {
                                        _requestType = item.Value.ToString();
                                    }
                                    else if (item.Name == "RES_TYPE")
                                    {
                                        _responseType = item.Value.ToString();
                                    }
                                    else if (item.Name == "REQUEST")
                                    {
                                        requestInput = item.Value.ToString();
                                    }
                                }
                            }
                        }
					}
				}

				if (requestInput != "")
				{
                    // Replace values from global variables
                    requestInput = SetReplaceRequestValues(requestInput);

					// Check request type to show/hide File Upload button
                    if (_requestType == "BinaryFile")
					{
						buttonBrowseFile.Visible = true;
					}
                    else
                    {
                        buttonBrowseFile.Visible = false;
                    }

					dynamic parsedJson = JsonConvert.DeserializeObject(requestInput.ToString());
                    inputRequestTabBeforeEncrypted.Text = JsonConvert.SerializeObject(parsedJson, Formatting.Indented);
                    _templateText = inputRequestTabBeforeEncrypted.Text;
					labelSampleName.Text = _requestData;
					buttonTapRequestBeforeEncrypted_Click(sender, e);
                    inputRequestTabSample.Text = interface_tester.GetTextFromFile(_requestData + ".txt");
                }
            }
        }

		#endregion

		#region Request Panel

        private void buttonApplyToRequest_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(textBoxUserId.Text))
            {
                MessageBox.Show("Please enter User ID.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = textBoxUserId;
            }
            else if (string.IsNullOrEmpty(textBoxDeviceId.Text))
            {
                MessageBox.Show("Please enter Device ID.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = textBoxDeviceId;
            }
            else if (string.IsNullOrEmpty(textBoxAuthKey.Text))
            {
                MessageBox.Show("Please enter Auth Key.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = textBoxAuthKey;
            }
            else
            {
                // Update global variables from input
                _userId = textBoxUserId.Text;
                _deviceId = textBoxDeviceId.Text;
                _authKey = textBoxAuthKey.Text;

                string requestJson = inputRequestTabBeforeEncrypted.Text.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
                string requestString = SetReplaceRequestValues(requestJson);
                dynamic parsedJson = JsonConvert.DeserializeObject(requestString);
                inputRequestTabBeforeEncrypted.Text = JsonConvert.SerializeObject(parsedJson, Formatting.Indented);
                
                buttonTapRequestBeforeEncrypted_Click(sender, e);
            }
		}

		private void buttonTabRequestSample_Click(object sender, EventArgs e)
		{
			panelRequestTabSample.BringToFront();
			buttonTabRequestSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            buttonTabRequestSample.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
			buttonTabRequestBeforeEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
			buttonTabRequestBeforeEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
			buttonTabRequestAfterEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
			buttonTabRequestAfterEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
		}

		private void buttonSampleSave_Click(object sender, EventArgs e)
		{
            if (string.IsNullOrEmpty(_requestData))
            {
                MessageBox.Show("Please select template on tree view list.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = interfaceTreeView;
            }
            else
            {
                if (string.IsNullOrEmpty(inputRequestTabSample.Text))
                {
                    MessageBox.Show("Please enter sample file data.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    this.ActiveControl = inputRequestTabSample;
                }
                else
                {
                    if ((MessageBox.Show("Are you sure you want to overwrite this file?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question)) == DialogResult.Yes)
                    {
                        inputRequestTabSample.Text = interface_tester.SetTextToFile(_requestData + ".txt", inputRequestTabSample.Text);
                    }
                }
            }
		}

		private void buttonSampleReset_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(_requestData))
            {
                MessageBox.Show("Please select template on tree view list.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = interfaceTreeView;
            }
            else
            {
                // Load from text file
                inputRequestTabSample.Text = "Loading...";
                inputRequestTabSample.Text = interface_tester.GetTextFromFile(_requestData + ".txt");
            }
		}

		private void buttonTapRequestBeforeEncrypted_Click(object sender, EventArgs e)
		{
			panelRequestTabBeforeEncrypted.BringToFront();
			buttonTabRequestSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            buttonTabRequestSample.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            buttonTabRequestBeforeEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            buttonTabRequestBeforeEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
			buttonTabRequestAfterEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
			buttonTabRequestAfterEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
		}

		private void buttonLoadSample_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(_requestData))
            {
                MessageBox.Show("Please select template on tree view list.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.ActiveControl = interfaceTreeView;
            }
            else
            {
                // Load from text file
                inputRequestTabBeforeEncrypted.Text = "Loading...";
                inputRequestTabBeforeEncrypted.Text = interface_tester.GetTextFromFile(_requestData + ".txt");
            }
		}

        private void buttonBrowseFile_Click(object sender, EventArgs e)
		{
			string requestInput = inputRequestTabBeforeEncrypted.Text;

			// Open file dialog
			if (_requestType == "BinaryFile")
			{
				JObject objUpload = JObject.Parse(requestInput.Replace("\r", " ").Replace("\n", " ").Replace("\t", " "));

				if (objUpload.Property("FILE_NAME") != null)
				{
					objUpload["FILE_NAME"] = OpenUploadFileDialog();
				}

				requestInput = objUpload.ToString();
				dynamic parsedJson = JsonConvert.DeserializeObject(requestInput.ToString());
				inputRequestTabBeforeEncrypted.Text = JsonConvert.SerializeObject(parsedJson, Formatting.Indented);
			}
		}

		private void buttonTabRequestAfterEncrypted_Click(object sender, EventArgs e)
		{
			panelRequestTabAfterEncrypted.BringToFront();
			buttonTabRequestSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
			buttonTabRequestSample.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
			buttonTabRequestBeforeEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
			buttonTabRequestBeforeEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
			buttonTabRequestAfterEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
			buttonTabRequestAfterEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
		}

		#endregion

		/// <summary>
		/// Send request data to get response from server
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void buttonSend_Click(object sender, EventArgs e)
		{
			string error = string.Empty;

			if (string.IsNullOrEmpty(textBoxEndpoint.Text) || textBoxEndpoint.Text == "http://" || textBoxEndpoint.Text == "https://")
			{
				MessageBox.Show("Please enter Endpoint URL.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.ActiveControl = textBoxEndpoint;
			}
			else if (!interface_tester.IsValidUrl(textBoxEndpoint.Text))
			{
				MessageBox.Show("Incorrect URL format. Please check Endpoint URL.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.ActiveControl = textBoxEndpoint;
			}
			else if (string.IsNullOrEmpty(inputRequestTabBeforeEncrypted.Text))
			{
				MessageBox.Show("Please enter request data.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
				this.ActiveControl = inputRequestTabSample;
			}
			else
			{
				string requestData = string.Empty;
				string requestToken = string.Empty;
				string requestResult = string.Empty;
				string requestHtml = string.Empty;
				string responseToken = string.Empty;
				string responseData = string.Empty;
				string responseResult = string.Empty;
				string responseHtml = string.Empty;

				// check JSON format
				error = interface_tester.IsValidJson(inputRequestTabBeforeEncrypted.Text);
				requestData = inputRequestTabBeforeEncrypted.Text.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ").ToString();

				// check validate value of json
				if (!interface_tester.ValidateJsonValue(requestData))
				{
					MessageBox.Show("Please check some of missing data.", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					this.ActiveControl = inputRequestTabBeforeEncrypted;
				}
				else
				{
					// Before each function invokes
					Cursor.Current = Cursors.WaitCursor;
					buttonSend.BackColor = Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(86)))), ((int)(((byte)(138)))));
					buttonSend.Text = "Sending..";
					outputResponseTabAfterDecrypted.Text = "Responding...";

					if (_targetIO == "INCOMING")
					{
						requestData = interface_tester.SetRegenerateTimestamp(requestData);
						requestToken = encode.EncryptTdes(requestData);
						dynamic requestJson = JsonConvert.DeserializeObject(requestData.ToString());
						requestResult = JsonConvert.SerializeObject(requestJson, Formatting.Indented);
						requestHtml = interface_tester.GetResultHTML("REQ", requestResult, requestToken);

						if (_requestType == "TextJson")
						{
							if (string.IsNullOrEmpty(error))
							{
								responseData = interface_tester.GetWebResponse(textBoxEndpoint.Text, requestData, out responseToken);
								responseResult = responseData;
							}
							else
							{
								responseResult = error;
							}
						}
						else if (_requestType == "BinaryFile")
						{
							if (string.IsNullOrEmpty(error))
							{
								// Set file path from openFileDialog
								string filePath = _uploadFile;

								try
								{
									NameValueCollection nameValueCollection = new NameValueCollection();
									nameValueCollection.Add("token", requestToken);
									responseToken = interface_tester.HttpUploadFile(textBoxEndpoint.Text, filePath, "file", "application/octet-stream", nameValueCollection);
									responseData = encode.DecryptTdes(responseToken);
									responseResult = responseData;
								}
								catch (Exception ex)
								{
									responseResult = ex.Message;
								}
							}
							else
							{
								responseResult = error;
							}
						}


						if (_responseType == "TextJson" || _responseType == "BinaryFile")
						{
							// check JSON format
							error = interface_tester.IsValidJson(responseData);

							if (string.IsNullOrEmpty(error))
							{
								json_helper jsonResponseHelper = new json_helper(responseData);

								if (jsonResponseHelper.GetJsonValue("RETURN_CODE") == _successReturnCode)
								{
									// Store to Gloval variable
									JObject objRequest = JObject.Parse(requestData);

									if (objRequest.Property("USER_ID") != null)
									{
										_userId = objRequest["USER_ID"].ToString();
										textBoxUserId.Text = _userId;
									}

									if (objRequest.Property("HMA_ID") != null)
									{
										_userId = objRequest["HMA_ID"].ToString();
										textBoxUserId.Text = _userId;
									}

									if (objRequest.Property("GMA_ID") != null)
									{
										_userId = objRequest["GMA_ID"].ToString();
										textBoxUserId.Text = _userId;
									}

									if (objRequest.Property("HAC_ID") != null)
									{
										_userId = objRequest["HAC_ID"].ToString();
										textBoxUserId.Text = _userId;
									}

									if (objRequest.Property("KMA_ID") != null)
									{
										_userId = objRequest["KMA_ID"].ToString();
										textBoxUserId.Text = _userId;
									}

									if (objRequest.Property("KCI_ID") != null)
									{
										_userId = objRequest["KCI_ID"].ToString();
										textBoxUserId.Text = _userId;
									}

									if (objRequest.Property("DEVICE_ID") != null)
									{
										_deviceId = objRequest["DEVICE_ID"].ToString();
										textBoxDeviceId.Text = _deviceId;
									}

									if (objRequest.Property("AUTH_KEY") != null)
									{
										_authKey = objRequest["AUTH_KEY"].ToString();
										textBoxAuthKey.Text = _authKey;
									}

									// Update current AuthKey
									string tmpAuthKey = jsonResponseHelper.GetJsonValue("AUTH_KEY");

									if (!string.IsNullOrEmpty(tmpAuthKey))
									{
										_authKey = tmpAuthKey;
										textBoxAuthKey.Text = _authKey;
									}
								}

								// After each function invokes
								dynamic responseJson = JsonConvert.DeserializeObject(responseData.ToString());
								responseResult = JsonConvert.SerializeObject(responseJson, Formatting.Indented);
							}
							else
							{
								responseResult = responseData;
							}
						}

						inputRequestTabAfterEncrypted.DocumentText = interface_tester.SetHtmlHeaderFooter(requestHtml);
						outputResponseTabAfterDecrypted.Text = responseResult;
						responseHtml = interface_tester.GetResultHTML("RES", responseResult, responseToken);
						outputResponseTabBeforeDecrypted.DocumentText = interface_tester.SetHtmlHeaderFooter(responseHtml);
					}
					else if (_targetIO == "OUTGOING")
					{
						if (_requestType == "AD_LOGIN_WS")
						{
							if (string.IsNullOrEmpty(error))
							{
								string dealerCode = string.Empty;
								string IAMUserID = string.Empty;
								string password = string.Empty;
								string identificationCode = string.Empty;
								string portalAuthenticationCode = string.Empty;
								string sourceSYSID = string.Empty;

								dynamic dynamicInput = JsonConvert.DeserializeObject(requestData.ToString());

								foreach (var itemInput in dynamicInput)
								{
									if (itemInput.Name == "dealerCode")
									{
										dealerCode = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "IAMUserID")
									{
										IAMUserID = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "password")
									{
										password = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "identificationCode")
									{
										identificationCode = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "portalAuthenticationCode")
									{
										portalAuthenticationCode = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "sourceSYSID")
									{
										sourceSYSID = itemInput.Value.ToString();
									}
								}

								json_helper jsonParser = new json_helper(requestData);
								string IFID = jsonParser.GetJsonValue("IFID");
								string COMPANY = jsonParser.GetJsonValue("COMPANY");
								string SENDER = jsonParser.GetJsonValue("SENDER");
								string RECEIVER = jsonParser.GetJsonValue("RECEIVER");

								string IFRESULT = ""; // Result
								string IFFAILMSG = ""; // Message

								requestResult = ""
									+ "dealerCode=\"" + dealerCode + "\"\n"
									+ "IAMUserID=\"" + IAMUserID + "\"\n"
									+ "password=\"" + password + "\"\n"
									+ "IFID=\"" + IFID + "\"\n"
									+ "COMPANY=\"" + COMPANY + "\"\n"
									+ "SENDER=\"" + SENDER + "\"\n"
									+ "RECEIVER=\"" + RECEIVER + "\"\n"
									+ "identificationCode=\"" + identificationCode + "\"\n"
									+ "portalAuthenticationCode=\"" + portalAuthenticationCode + "\"\n"
									+ "sourceSYSID=\"" + sourceSYSID + "\"";

								requestHtml = interface_tester.GetResultHTML("REQ", requestResult, requestResult);

								try
								{
									// define InData
									AD_LOGIN_WS.IN_DATA objInData = new AD_LOGIN_WS.IN_DATA();

									// set InData properties
									objInData.dealerCode = dealerCode;
									objInData.IAMUserID = IAMUserID;
									objInData.password = password;
									objInData.identificationCode = identificationCode;
									objInData.portalAuthenticationCode = portalAuthenticationCode;
									objInData.sourceSYSID = sourceSYSID;

									AD_LOGIN_WS.HEP_ISSOLGC003_PortTypeClient objWsRequest = new AD_LOGIN_WS.HEP_ISSOLGC003_PortTypeClient("VS_GITA_PDI_CommSupplierEP.WEBDCS.HEP_ISSOLGC003soaphttps");

									if (_targetIO == "STAGE")
									{
										objWsRequest.Endpoint.Address = new System.ServiceModel.EndpointAddress("https://wmexts.hmausa.com:5129/ws/VS_GITA_HTI_CommSupplierEP.WEBDCS.HEP_ISSOLGC003.VS_GITA_HTI_CommSupplierEP.WEBDCS.HEP_ISSOLGC003soaphttps");
									}
									else if (_targetIO == "PROD")
									{
										objWsRequest.Endpoint.Address = new System.ServiceModel.EndpointAddress("https://wmextp.hmausa.com:5129/ws/VS_GITA_HTI_CommSupplierEP.WEBDCS.HEP_ISSOLGC003.VS_GITA_HTI_CommSupplierEP.WEBDCS.HEP_ISSOLGC003soaphttps");
									}

									objWsRequest.ClientCredentials.UserName.UserName = identificationCode;
									objWsRequest.ClientCredentials.UserName.Password = portalAuthenticationCode;

									// define OUtData
									AD_LOGIN_WS.OUT_DATA objOutData = new AD_LOGIN_WS.OUT_DATA();

									IFRESULT = objWsRequest.HEP_ISSOLGC003request(IFID, COMPANY, SENDER, RECEIVER, objInData, out IFFAILMSG, out objOutData);
									responseResult = JsonConvert.SerializeObject(objOutData, Formatting.Indented);
									responseToken = interface_tester.JsonToString(responseResult);
								}
								catch (Exception ex)
								{
									responseResult = ex.ToString();
								}
							}
							else
							{
								responseResult = error;
							}
						}
						else if (_requestType == "ID_CHECK_WS")
						{
							if (string.IsNullOrEmpty(error))
							{
								string dealerCode = string.Empty;
								string IAMUserID = string.Empty;
								string identificationCode = string.Empty;
								string portalAuthenticationCode = string.Empty;
								string sourceSYSID = string.Empty;

								dynamic dynamicInput = JsonConvert.DeserializeObject(requestData.ToString());

								foreach (var itemInput in dynamicInput)
								{
									if (itemInput.Name == "dealerCode")
									{
										dealerCode = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "IAMUserID")
									{
										IAMUserID = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "identificationCode")
									{
										identificationCode = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "portalAuthenticationCode")
									{
										portalAuthenticationCode = itemInput.Value.ToString();
									}
									else if (itemInput.Name == "sourceSYSID")
									{
										sourceSYSID = itemInput.Value.ToString();
									}
								}

								json_helper jsonParser = new json_helper(requestData);
								string IFID = jsonParser.GetJsonValue("IFID");
								string COMPANY = jsonParser.GetJsonValue("COMPANY");
								string SENDER = jsonParser.GetJsonValue("SENDER");
								string RECEIVER = jsonParser.GetJsonValue("RECEIVER");

								string IFRESULT = ""; // Result
								string IFFAILMSG = ""; // Message

								requestResult = ""
									+ "dealerCode=\"" + dealerCode + "\"\n"
									+ "IAMUserID=\"" + IAMUserID + "\"\n"
									+ "IFID=\"" + IFID + "\"\n"
									+ "COMPANY=\"" + COMPANY + "\"\n"
									+ "SENDER=\"" + SENDER + "\"\n"
									+ "RECEIVER=\"" + RECEIVER + "\"\n"
									+ "identificationCode=\"" + identificationCode + "\"\n"
									+ "portalAuthenticationCode=\"" + portalAuthenticationCode + "\"\n"
									+ "sourceSYSID=\"" + sourceSYSID + "\"";

								requestHtml = interface_tester.GetResultHTML("REQ", requestResult, requestResult);

								try
								{
									// define InData
									ID_CHECK_WS.IN_DATA objInData = new ID_CHECK_WS.IN_DATA();

									// set InData properties
									objInData.dealerCode = dealerCode;
									objInData.IAMUserID = IAMUserID;
									objInData.identificationCode = identificationCode;
									objInData.portalAuthenticationCode = portalAuthenticationCode;
									objInData.sourceSYSID = sourceSYSID;

									ID_CHECK_WS.HEP_ISSOLGC004_PortTypeClient objWsRequest = new ID_CHECK_WS.HEP_ISSOLGC004_PortTypeClient("VS_GITA_PDI_CommSupplierEP.WEBDCS.HEP_ISSOLGC004soaphttps");

									if (_targetIO == "STAGE")
									{
										objWsRequest.Endpoint.Address = new System.ServiceModel.EndpointAddress("https://wmexts.hmausa.com:5129/ws/VS_GITA_PDI_CommSupplierEP.WEBDCS.HEP_ISSOLGC004.VS_GITA_PDI_CommSupplierEP.WEBDCS.HEP_ISSOLGC004soaphttps");
									}
									else if (_targetIO == "PROD")
									{
										objWsRequest.Endpoint.Address = new System.ServiceModel.EndpointAddress("https://wmextp.hmausa.com:5129/ws/VS_GITA_PDI_CommSupplierEP.WEBDCS.HEP_ISSOLGC004.VS_GITA_PDI_CommSupplierEP.WEBDCS.HEP_ISSOLGC004soaphttps");
									}

									objWsRequest.ClientCredentials.UserName.UserName = identificationCode;
									objWsRequest.ClientCredentials.UserName.Password = portalAuthenticationCode;

									// define OUtData
									ID_CHECK_WS.OUT_DATA objOutData = new ID_CHECK_WS.OUT_DATA();

									IFRESULT = objWsRequest.HEP_ISSOLGC004request(IFID, COMPANY, SENDER, RECEIVER, objInData, out IFFAILMSG, out objOutData);
									responseResult = JsonConvert.SerializeObject(objOutData, Formatting.Indented);
									responseToken = interface_tester.JsonToString(responseResult);
								}
								catch (Exception ex)
								{
									responseResult = ex.ToString();
								}
							}
							else
							{
								responseResult = error;
							}
						}

						responseHtml = interface_tester.GetResultHTML("RES", responseToken, responseToken);
						inputRequestTabAfterEncrypted.DocumentText = interface_tester.SetHtmlHeaderFooter(requestHtml);
						outputResponseTabAfterDecrypted.Text = responseResult;
						outputResponseTabBeforeDecrypted.DocumentText = interface_tester.SetHtmlHeaderFooter(responseHtml);
					}

					// After receive response
					buttonSend.Text = "Send";
					buttonSend.BackColor = Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(124)))), ((int)(((byte)(229)))));
					Cursor.Current = Cursors.Hand;
					buttonTapRequestBeforeEncrypted_Click(sender, e);
					buttonTabResponseAfterDecrypted_Click(sender, e);
				}
			}
		}

		#region Response Panel

		private void buttonTabResponseBeforeDecrypted_Click(object sender, EventArgs e)
		{
			panelResponseTabBeforeDecrypted.BringToFront();
			buttonTabResponseBeforeDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
			buttonTabResponseBeforeDecrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
			buttonTabResponseAfterDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
			buttonTabResponseAfterDecrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
		}

		private void buttonTabResponseAfterDecrypted_Click(object sender, EventArgs e)
		{
			panelResponseTabAfterDecrypted.BringToFront();
			buttonTabResponseBeforeDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
			buttonTabResponseBeforeDecrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
			buttonTabResponseAfterDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
			buttonTabResponseAfterDecrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
		}

		#endregion

		#endregion

		#region Internal Functions

        private void SetInterfaceType(string targetIO = null, string targetType = null)
        {
            if (!string.IsNullOrEmpty(targetIO))
            {
                _targetIO = targetIO;
            }

            if (!string.IsNullOrEmpty(targetType))
            {
                _targetType = targetType;
            }
        }

        private void SetInterfaceTreeView(string targetIO = null, string targetType = null)
        {
            string jsonTreeParent = string.Empty;
			string jsonTreeChildren = string.Empty;

            // Store interface type
            SetInterfaceType(targetIO, targetType);

            // Initialize template data from JSON file
			_templateJSON = interface_tester.GetJsonFromFile("template.json");
            JObject jsonTree = new JObject(); 
            JObject objRequests = JObject.Parse(_templateJSON);
            dynamic dynamicJson = JsonConvert.DeserializeObject(objRequests[_targetIO].ToString());

            foreach (var itemParent in dynamicJson)
            {
				jsonTreeParent = itemParent.Name;
				jsonTreeChildren = "{\n";

				foreach (var itemChildren in itemParent.Value)
				{
					jsonTreeChildren += "\"" + itemChildren.Name + "\": {},\n";
				}

				jsonTreeChildren += "}\n";
				jsonTree.Add(jsonTreeParent, JObject.Parse(jsonTreeChildren));
			}

			interfaceTreeView.Nodes.Clear();
			interfaceTreeView.Visible = true;
            interface_tester.GetJsonToTreeView(interfaceTreeView, "ROOT", jsonTree.ToString());
            interfaceTreeView.ExpandAll();
        }
        
        public static string SetReplaceRequestValues(string requestInput)
		{
			string result = requestInput.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");

            if (result != string.Empty)
            {
                JObject objRequest = JObject.Parse(result);

                if (objRequest.Property("USER_ID") != null)
                {
                    objRequest["USER_ID"] = _userId;
                }

                if (objRequest.Property("HMA_ID") != null)
                {
                    objRequest["HMA_ID"] = _userId;
                }

                if (objRequest.Property("DEVICE_ID") != null)
                {
                    objRequest["DEVICE_ID"] = _deviceId;
                }

                if (objRequest.Property("AUTH_KEY") != null)
                {
                    objRequest["AUTH_KEY"] = _authKey;
                }

                result = objRequest.ToString();
            }

            return result;
		}

        public static string OpenUploadFileDialog()
		{
            string result = string.Empty;

			OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "All Files|*.*";
			openFileDialog.Title = "Open";

			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
			    _uploadFile = openFileDialog.FileName;
				result = Path.GetFileName(openFileDialog.FileName);
			}

            return result;
		}

		public static void OpenSaveFileDialog(string fileName, out string filePath)
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "All Files|*.*";
			saveFileDialog.Title = "Save As";
			saveFileDialog.FileName = fileName;

            filePath = string.Empty;

			if (saveFileDialog.ShowDialog() == DialogResult.OK)
			{
			    filePath = saveFileDialog.FileName;
			}
		}

        #endregion
	}
}
