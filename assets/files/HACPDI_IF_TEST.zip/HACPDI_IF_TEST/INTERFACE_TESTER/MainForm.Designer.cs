﻿using System.Windows.Forms;

namespace INTERFACE_TESTER
{
	partial class MainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.splitContainerMain = new System.Windows.Forms.SplitContainer();
            this.panelInterfaceTypeContainer = new System.Windows.Forms.Panel();
            this.tableLayoutPanelInterfaceContainer = new System.Windows.Forms.TableLayoutPanel();
            this.panelInterfaceTypeHeader = new System.Windows.Forms.Panel();
            this.tableLayoutPanelInterfaceType = new System.Windows.Forms.TableLayoutPanel();
            this.buttonTabIncoming = new System.Windows.Forms.Button();
            this.buttonTabOutgoing = new System.Windows.Forms.Button();
            this.panelInterfaceTabContainer = new System.Windows.Forms.Panel();
            this.panelInterfaceTabIncoming = new System.Windows.Forms.Panel();
            this.buttonTabIncomingLocal = new System.Windows.Forms.Button();
            this.buttonTabIncomingStage = new System.Windows.Forms.Button();
            this.buttonTabIncomingProd = new System.Windows.Forms.Button();
            this.panelInterfaceTabOutgoing = new System.Windows.Forms.Panel();
            this.buttonTabOutgoingStage = new System.Windows.Forms.Button();
            this.buttonTabOutgoingProd = new System.Windows.Forms.Button();
            this.panelInterfaceTypeBody = new System.Windows.Forms.Panel();
            this.tableLayoutPanelIncomingURLHost = new System.Windows.Forms.TableLayoutPanel();
            this.panelIncomingURLHost = new System.Windows.Forms.Panel();
            this.textBoxURLHost = new System.Windows.Forms.TextBox();
            this.buttonUpdateURLHost = new System.Windows.Forms.Button();
            this.panelInterfaceTreeView = new System.Windows.Forms.Panel();
            this.interfaceTreeView = new System.Windows.Forms.TreeView();
            this.tableLayoutPanelBodyContainer = new System.Windows.Forms.TableLayoutPanel();
            this.panelBodyHeaderContainer = new System.Windows.Forms.Panel();
            this.tableLayoutPanelBodyHeader = new System.Windows.Forms.TableLayoutPanel();
            this.labelUserId = new System.Windows.Forms.Label();
            this.panelTextBoxUserId = new System.Windows.Forms.Panel();
            this.textBoxUserId = new System.Windows.Forms.TextBox();
            this.labelDeviceId = new System.Windows.Forms.Label();
            this.panelTextBoxDeviceId = new System.Windows.Forms.Panel();
            this.textBoxDeviceId = new System.Windows.Forms.TextBox();
            this.labelAuthKey = new System.Windows.Forms.Label();
            this.panelTextBoxAuthKey = new System.Windows.Forms.Panel();
            this.textBoxAuthKey = new System.Windows.Forms.TextBox();
            this.panelBodyHeaderButton = new System.Windows.Forms.Panel();
            this.buttonApplyToRequest = new System.Windows.Forms.Button();
            this.panelBodySectionContainer = new System.Windows.Forms.Panel();
            this.tableLayoutPanelBodySection = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelBodyEndpoint = new System.Windows.Forms.TableLayoutPanel();
            this.panelBodyHeaderEndpoint = new System.Windows.Forms.Panel();
            this.panelBodyHeaderEndpointBox = new System.Windows.Forms.Panel();
            this.textBoxEndpoint = new System.Windows.Forms.TextBox();
            this.buttonSend = new System.Windows.Forms.Button();
            this.splitContainerBody = new System.Windows.Forms.SplitContainer();
            this.tableLayoutPanelRequestContainer = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanelRequestTabHeader = new System.Windows.Forms.TableLayoutPanel();
            this.panelRequestTabContainer = new System.Windows.Forms.Panel();
            this.buttonTabRequestSample = new System.Windows.Forms.Button();
            this.buttonTabRequestBeforeEncrypted = new System.Windows.Forms.Button();
            this.buttonTabRequestAfterEncrypted = new System.Windows.Forms.Button();
            this.panelRequestContainer = new System.Windows.Forms.Panel();
            this.panelRequestTabSample = new System.Windows.Forms.Panel();
            this.tableLayoutPanelRequestTabSample = new System.Windows.Forms.TableLayoutPanel();
            this.labelSampleName = new System.Windows.Forms.Label();
            this.inputRequestTabSample = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanelRequestTabSampleFooter = new System.Windows.Forms.TableLayoutPanel();
            this.buttonSampleSave = new System.Windows.Forms.Button();
            this.buttonSampleReset = new System.Windows.Forms.Button();
            this.panelRequestTabBeforeEncrypted = new System.Windows.Forms.Panel();
            this.tableLayoutPanelRequestTabBeforeEncrypted = new System.Windows.Forms.TableLayoutPanel();
            this.inputRequestTabBeforeEncrypted = new System.Windows.Forms.RichTextBox();
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader = new System.Windows.Forms.TableLayoutPanel();
            this.buttonBrowseFile = new System.Windows.Forms.Button();
            this.buttonLoadSample = new System.Windows.Forms.Button();
            this.panelRequestTabAfterEncrypted = new System.Windows.Forms.Panel();
            this.inputRequestTabAfterEncrypted = new System.Windows.Forms.WebBrowser();
            this.tableLayoutPanelResponseContainer = new System.Windows.Forms.TableLayoutPanel();
            this.panelResponseTabContainer = new System.Windows.Forms.Panel();
            this.buttonTabResponseBeforeDecrypted = new System.Windows.Forms.Button();
            this.buttonTabResponseAfterDecrypted = new System.Windows.Forms.Button();
            this.panelResponseContainer = new System.Windows.Forms.Panel();
            this.panelResponseTabAfterDecrypted = new System.Windows.Forms.Panel();
            this.outputResponseTabAfterDecrypted = new System.Windows.Forms.RichTextBox();
            this.panelResponseTabBeforeDecrypted = new System.Windows.Forms.Panel();
            this.outputResponseTabBeforeDecrypted = new System.Windows.Forms.WebBrowser();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerMain)).BeginInit();
            this.splitContainerMain.Panel1.SuspendLayout();
            this.splitContainerMain.Panel2.SuspendLayout();
            this.splitContainerMain.SuspendLayout();
            this.panelInterfaceTypeContainer.SuspendLayout();
            this.tableLayoutPanelInterfaceContainer.SuspendLayout();
            this.panelInterfaceTypeHeader.SuspendLayout();
            this.tableLayoutPanelInterfaceType.SuspendLayout();
            this.panelInterfaceTabContainer.SuspendLayout();
            this.panelInterfaceTabIncoming.SuspendLayout();
            this.panelInterfaceTabOutgoing.SuspendLayout();
            this.panelInterfaceTypeBody.SuspendLayout();
            this.tableLayoutPanelIncomingURLHost.SuspendLayout();
            this.panelIncomingURLHost.SuspendLayout();
            this.panelInterfaceTreeView.SuspendLayout();
            this.tableLayoutPanelBodyContainer.SuspendLayout();
            this.panelBodyHeaderContainer.SuspendLayout();
            this.tableLayoutPanelBodyHeader.SuspendLayout();
            this.panelTextBoxUserId.SuspendLayout();
            this.panelTextBoxDeviceId.SuspendLayout();
            this.panelTextBoxAuthKey.SuspendLayout();
            this.panelBodyHeaderButton.SuspendLayout();
            this.panelBodySectionContainer.SuspendLayout();
            this.tableLayoutPanelBodySection.SuspendLayout();
            this.tableLayoutPanelBodyEndpoint.SuspendLayout();
            this.panelBodyHeaderEndpoint.SuspendLayout();
            this.panelBodyHeaderEndpointBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerBody)).BeginInit();
            this.splitContainerBody.Panel1.SuspendLayout();
            this.splitContainerBody.Panel2.SuspendLayout();
            this.splitContainerBody.SuspendLayout();
            this.tableLayoutPanelRequestContainer.SuspendLayout();
            this.tableLayoutPanelRequestTabHeader.SuspendLayout();
            this.panelRequestTabContainer.SuspendLayout();
            this.panelRequestContainer.SuspendLayout();
            this.panelRequestTabSample.SuspendLayout();
            this.tableLayoutPanelRequestTabSample.SuspendLayout();
            this.tableLayoutPanelRequestTabSampleFooter.SuspendLayout();
            this.panelRequestTabBeforeEncrypted.SuspendLayout();
            this.tableLayoutPanelRequestTabBeforeEncrypted.SuspendLayout();
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.SuspendLayout();
            this.panelRequestTabAfterEncrypted.SuspendLayout();
            this.tableLayoutPanelResponseContainer.SuspendLayout();
            this.panelResponseTabContainer.SuspendLayout();
            this.panelResponseContainer.SuspendLayout();
            this.panelResponseTabAfterDecrypted.SuspendLayout();
            this.panelResponseTabBeforeDecrypted.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainerMain
            // 
            this.splitContainerMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.splitContainerMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerMain.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(67)))), ((int)(((byte)(67)))));
            this.splitContainerMain.Location = new System.Drawing.Point(0, 0);
            this.splitContainerMain.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainerMain.Name = "splitContainerMain";
            // 
            // splitContainerMain.Panel1
            // 
            this.splitContainerMain.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.splitContainerMain.Panel1.Controls.Add(this.panelInterfaceTypeContainer);
            this.splitContainerMain.Panel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.splitContainerMain.Panel1.ForeColor = System.Drawing.Color.Silver;
            this.splitContainerMain.Panel1MinSize = 180;
            // 
            // splitContainerMain.Panel2
            // 
            this.splitContainerMain.Panel2.Controls.Add(this.tableLayoutPanelBodyContainer);
            this.splitContainerMain.Panel2MinSize = 520;
            this.splitContainerMain.Size = new System.Drawing.Size(1024, 641);
            this.splitContainerMain.SplitterDistance = 220;
            this.splitContainerMain.TabIndex = 1;
            // 
            // panelInterfaceTypeContainer
            // 
            this.panelInterfaceTypeContainer.Controls.Add(this.tableLayoutPanelInterfaceContainer);
            this.panelInterfaceTypeContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInterfaceTypeContainer.Location = new System.Drawing.Point(0, 0);
            this.panelInterfaceTypeContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelInterfaceTypeContainer.Name = "panelInterfaceTypeContainer";
            this.panelInterfaceTypeContainer.Padding = new System.Windows.Forms.Padding(5, 0, 0, 5);
            this.panelInterfaceTypeContainer.Size = new System.Drawing.Size(220, 641);
            this.panelInterfaceTypeContainer.TabIndex = 1;
            // 
            // tableLayoutPanelInterfaceContainer
            // 
            this.tableLayoutPanelInterfaceContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tableLayoutPanelInterfaceContainer.ColumnCount = 1;
            this.tableLayoutPanelInterfaceContainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelInterfaceContainer.Controls.Add(this.panelInterfaceTypeHeader, 0, 1);
            this.tableLayoutPanelInterfaceContainer.Controls.Add(this.panelInterfaceTabContainer, 0, 2);
            this.tableLayoutPanelInterfaceContainer.Controls.Add(this.panelInterfaceTypeBody, 0, 3);
            this.tableLayoutPanelInterfaceContainer.Controls.Add(this.panelInterfaceTreeView, 0, 4);
            this.tableLayoutPanelInterfaceContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelInterfaceContainer.Location = new System.Drawing.Point(5, 0);
            this.tableLayoutPanelInterfaceContainer.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelInterfaceContainer.Name = "tableLayoutPanelInterfaceContainer";
            this.tableLayoutPanelInterfaceContainer.RowCount = 5;
            this.tableLayoutPanelInterfaceContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanelInterfaceContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanelInterfaceContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanelInterfaceContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelInterfaceContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelInterfaceContainer.Size = new System.Drawing.Size(215, 636);
            this.tableLayoutPanelInterfaceContainer.TabIndex = 1;
            // 
            // panelInterfaceTypeHeader
            // 
            this.panelInterfaceTypeHeader.Controls.Add(this.tableLayoutPanelInterfaceType);
            this.panelInterfaceTypeHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInterfaceTypeHeader.Location = new System.Drawing.Point(0, 5);
            this.panelInterfaceTypeHeader.Margin = new System.Windows.Forms.Padding(0);
            this.panelInterfaceTypeHeader.Name = "panelInterfaceTypeHeader";
            this.panelInterfaceTypeHeader.Size = new System.Drawing.Size(215, 33);
            this.panelInterfaceTypeHeader.TabIndex = 1;
            // 
            // tableLayoutPanelInterfaceType
            // 
            this.tableLayoutPanelInterfaceType.ColumnCount = 2;
            this.tableLayoutPanelInterfaceType.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelInterfaceType.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelInterfaceType.Controls.Add(this.buttonTabIncoming, 0, 0);
            this.tableLayoutPanelInterfaceType.Controls.Add(this.buttonTabOutgoing, 1, 0);
            this.tableLayoutPanelInterfaceType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelInterfaceType.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelInterfaceType.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelInterfaceType.Name = "tableLayoutPanelInterfaceType";
            this.tableLayoutPanelInterfaceType.RowCount = 1;
            this.tableLayoutPanelInterfaceType.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelInterfaceType.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanelInterfaceType.Size = new System.Drawing.Size(215, 33);
            this.tableLayoutPanelInterfaceType.TabIndex = 0;
            // 
            // buttonTabIncoming
            // 
            this.buttonTabIncoming.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.buttonTabIncoming.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabIncoming.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTabIncoming.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.buttonTabIncoming.FlatAppearance.BorderSize = 0;
            this.buttonTabIncoming.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(58)))));
            this.buttonTabIncoming.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.buttonTabIncoming.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabIncoming.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabIncoming.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
            this.buttonTabIncoming.Location = new System.Drawing.Point(0, 3);
            this.buttonTabIncoming.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.buttonTabIncoming.Name = "buttonTabIncoming";
            this.buttonTabIncoming.Size = new System.Drawing.Size(107, 30);
            this.buttonTabIncoming.TabIndex = 1;
            this.buttonTabIncoming.Text = "Incoming";
            this.buttonTabIncoming.UseVisualStyleBackColor = false;
            this.buttonTabIncoming.Click += new System.EventHandler(this.buttonTabIncoming_Click);
            // 
            // buttonTabOutgoing
            // 
            this.buttonTabOutgoing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.buttonTabOutgoing.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabOutgoing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTabOutgoing.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.buttonTabOutgoing.FlatAppearance.BorderSize = 0;
            this.buttonTabOutgoing.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(58)))), ((int)(((byte)(58)))));
            this.buttonTabOutgoing.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.buttonTabOutgoing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabOutgoing.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabOutgoing.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.buttonTabOutgoing.Location = new System.Drawing.Point(107, 3);
            this.buttonTabOutgoing.Margin = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.buttonTabOutgoing.Name = "buttonTabOutgoing";
            this.buttonTabOutgoing.Size = new System.Drawing.Size(108, 30);
            this.buttonTabOutgoing.TabIndex = 1;
            this.buttonTabOutgoing.Text = "Outgoing";
            this.buttonTabOutgoing.UseVisualStyleBackColor = false;
            this.buttonTabOutgoing.Click += new System.EventHandler(this.buttonTabOutgoing_Click);
            // 
            // panelInterfaceTabContainer
            // 
            this.panelInterfaceTabContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panelInterfaceTabContainer.Controls.Add(this.panelInterfaceTabIncoming);
            this.panelInterfaceTabContainer.Controls.Add(this.panelInterfaceTabOutgoing);
            this.panelInterfaceTabContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInterfaceTabContainer.Location = new System.Drawing.Point(0, 38);
            this.panelInterfaceTabContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelInterfaceTabContainer.Name = "panelInterfaceTabContainer";
            this.panelInterfaceTabContainer.Size = new System.Drawing.Size(215, 35);
            this.panelInterfaceTabContainer.TabIndex = 1;
            // 
            // panelInterfaceTabIncoming
            // 
            this.panelInterfaceTabIncoming.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panelInterfaceTabIncoming.Controls.Add(this.buttonTabIncomingLocal);
            this.panelInterfaceTabIncoming.Controls.Add(this.buttonTabIncomingStage);
            this.panelInterfaceTabIncoming.Controls.Add(this.buttonTabIncomingProd);
            this.panelInterfaceTabIncoming.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInterfaceTabIncoming.Location = new System.Drawing.Point(0, 0);
            this.panelInterfaceTabIncoming.Margin = new System.Windows.Forms.Padding(0);
            this.panelInterfaceTabIncoming.Name = "panelInterfaceTabIncoming";
            this.panelInterfaceTabIncoming.Size = new System.Drawing.Size(215, 35);
            this.panelInterfaceTabIncoming.TabIndex = 1;
            // 
            // buttonTabIncomingLocal
            // 
            this.buttonTabIncomingLocal.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonTabIncomingLocal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.buttonTabIncomingLocal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabIncomingLocal.FlatAppearance.BorderSize = 0;
            this.buttonTabIncomingLocal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabIncomingLocal.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabIncomingLocal.ForeColor = System.Drawing.Color.Gray;
            this.buttonTabIncomingLocal.Location = new System.Drawing.Point(6, 9);
            this.buttonTabIncomingLocal.Name = "buttonTabIncomingLocal";
            this.buttonTabIncomingLocal.Size = new System.Drawing.Size(53, 23);
            this.buttonTabIncomingLocal.TabIndex = 1;
            this.buttonTabIncomingLocal.Text = "Local";
            this.buttonTabIncomingLocal.UseVisualStyleBackColor = false;
            this.buttonTabIncomingLocal.Click += new System.EventHandler(this.buttonTabIncomingLocal_Click);
            // 
            // buttonTabIncomingStage
            // 
            this.buttonTabIncomingStage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonTabIncomingStage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonTabIncomingStage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabIncomingStage.FlatAppearance.BorderSize = 0;
            this.buttonTabIncomingStage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabIncomingStage.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabIncomingStage.ForeColor = System.Drawing.Color.Silver;
            this.buttonTabIncomingStage.Location = new System.Drawing.Point(65, 9);
            this.buttonTabIncomingStage.Name = "buttonTabIncomingStage";
            this.buttonTabIncomingStage.Size = new System.Drawing.Size(53, 23);
            this.buttonTabIncomingStage.TabIndex = 1;
            this.buttonTabIncomingStage.Text = "Stage";
            this.buttonTabIncomingStage.UseVisualStyleBackColor = false;
            this.buttonTabIncomingStage.Click += new System.EventHandler(this.buttonTabIncomingStage_Click);
            // 
            // buttonTabIncomingProd
            // 
            this.buttonTabIncomingProd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonTabIncomingProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
            this.buttonTabIncomingProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabIncomingProd.FlatAppearance.BorderSize = 0;
            this.buttonTabIncomingProd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabIncomingProd.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabIncomingProd.ForeColor = System.Drawing.Color.Gray;
            this.buttonTabIncomingProd.Location = new System.Drawing.Point(124, 9);
            this.buttonTabIncomingProd.Name = "buttonTabIncomingProd";
            this.buttonTabIncomingProd.Size = new System.Drawing.Size(53, 23);
            this.buttonTabIncomingProd.TabIndex = 1;
            this.buttonTabIncomingProd.Text = "Prod.";
            this.buttonTabIncomingProd.UseVisualStyleBackColor = false;
            this.buttonTabIncomingProd.Click += new System.EventHandler(this.buttonTabIncomingProd_Click);
            // 
            // panelInterfaceTabOutgoing
            // 
            this.panelInterfaceTabOutgoing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panelInterfaceTabOutgoing.Controls.Add(this.buttonTabOutgoingStage);
            this.panelInterfaceTabOutgoing.Controls.Add(this.buttonTabOutgoingProd);
            this.panelInterfaceTabOutgoing.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInterfaceTabOutgoing.Location = new System.Drawing.Point(0, 0);
            this.panelInterfaceTabOutgoing.Margin = new System.Windows.Forms.Padding(0);
            this.panelInterfaceTabOutgoing.Name = "panelInterfaceTabOutgoing";
            this.panelInterfaceTabOutgoing.Size = new System.Drawing.Size(215, 35);
            this.panelInterfaceTabOutgoing.TabIndex = 1;
            // 
            // buttonTabOutgoingStage
            // 
            this.buttonTabOutgoingStage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonTabOutgoingStage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonTabOutgoingStage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabOutgoingStage.FlatAppearance.BorderSize = 0;
            this.buttonTabOutgoingStage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabOutgoingStage.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabOutgoingStage.ForeColor = System.Drawing.Color.Silver;
            this.buttonTabOutgoingStage.Location = new System.Drawing.Point(6, 8);
            this.buttonTabOutgoingStage.Name = "buttonTabOutgoingStage";
            this.buttonTabOutgoingStage.Size = new System.Drawing.Size(53, 23);
            this.buttonTabOutgoingStage.TabIndex = 1;
            this.buttonTabOutgoingStage.Text = "Stage";
            this.buttonTabOutgoingStage.UseVisualStyleBackColor = false;
            this.buttonTabOutgoingStage.Click += new System.EventHandler(this.buttonTabOutgoingStage_Click);
            // 
            // buttonTabOutgoingProd
            // 
            this.buttonTabOutgoingProd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonTabOutgoingProd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonTabOutgoingProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabOutgoingProd.FlatAppearance.BorderSize = 0;
            this.buttonTabOutgoingProd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabOutgoingProd.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabOutgoingProd.ForeColor = System.Drawing.Color.Gray;
            this.buttonTabOutgoingProd.Location = new System.Drawing.Point(65, 8);
            this.buttonTabOutgoingProd.Name = "buttonTabOutgoingProd";
            this.buttonTabOutgoingProd.Size = new System.Drawing.Size(53, 23);
            this.buttonTabOutgoingProd.TabIndex = 1;
            this.buttonTabOutgoingProd.Text = "Prod.";
            this.buttonTabOutgoingProd.UseVisualStyleBackColor = false;
            this.buttonTabOutgoingProd.Click += new System.EventHandler(this.buttonTabOutgoingProd_Click);
            // 
            // panelInterfaceTypeBody
            // 
            this.panelInterfaceTypeBody.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panelInterfaceTypeBody.Controls.Add(this.tableLayoutPanelIncomingURLHost);
            this.panelInterfaceTypeBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInterfaceTypeBody.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.panelInterfaceTypeBody.Location = new System.Drawing.Point(0, 73);
            this.panelInterfaceTypeBody.Margin = new System.Windows.Forms.Padding(0);
            this.panelInterfaceTypeBody.Name = "panelInterfaceTypeBody";
            this.panelInterfaceTypeBody.Size = new System.Drawing.Size(215, 34);
            this.panelInterfaceTypeBody.TabIndex = 1;
            // 
            // tableLayoutPanelIncomingURLHost
            // 
            this.tableLayoutPanelIncomingURLHost.ColumnCount = 2;
            this.tableLayoutPanelIncomingURLHost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelIncomingURLHost.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 56F));
            this.tableLayoutPanelIncomingURLHost.Controls.Add(this.panelIncomingURLHost, 0, 0);
            this.tableLayoutPanelIncomingURLHost.Controls.Add(this.buttonUpdateURLHost, 1, 0);
            this.tableLayoutPanelIncomingURLHost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelIncomingURLHost.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelIncomingURLHost.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelIncomingURLHost.Name = "tableLayoutPanelIncomingURLHost";
            this.tableLayoutPanelIncomingURLHost.RowCount = 2;
            this.tableLayoutPanelIncomingURLHost.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanelIncomingURLHost.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelIncomingURLHost.Size = new System.Drawing.Size(215, 34);
            this.tableLayoutPanelIncomingURLHost.TabIndex = 1;
            // 
            // panelIncomingURLHost
            // 
            this.panelIncomingURLHost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelIncomingURLHost.Controls.Add(this.textBoxURLHost);
            this.panelIncomingURLHost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelIncomingURLHost.Location = new System.Drawing.Point(6, 3);
            this.panelIncomingURLHost.Margin = new System.Windows.Forms.Padding(6, 3, 0, 3);
            this.panelIncomingURLHost.Name = "panelIncomingURLHost";
            this.panelIncomingURLHost.Padding = new System.Windows.Forms.Padding(6, 3, 0, 3);
            this.panelIncomingURLHost.Size = new System.Drawing.Size(153, 22);
            this.panelIncomingURLHost.TabIndex = 1;
            // 
            // textBoxURLHost
            // 
            this.textBoxURLHost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxURLHost.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxURLHost.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxURLHost.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.textBoxURLHost.ForeColor = System.Drawing.Color.LightGray;
            this.textBoxURLHost.Location = new System.Drawing.Point(6, 3);
            this.textBoxURLHost.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxURLHost.Name = "textBoxURLHost";
            this.textBoxURLHost.Size = new System.Drawing.Size(147, 16);
            this.textBoxURLHost.TabIndex = 1;
            // 
            // buttonUpdateURLHost
            // 
            this.buttonUpdateURLHost.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.buttonUpdateURLHost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(114)))), ((int)(((byte)(72)))));
            this.buttonUpdateURLHost.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonUpdateURLHost.FlatAppearance.BorderSize = 0;
            this.buttonUpdateURLHost.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUpdateURLHost.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUpdateURLHost.ForeColor = System.Drawing.Color.White;
            this.buttonUpdateURLHost.Location = new System.Drawing.Point(164, 4);
            this.buttonUpdateURLHost.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.buttonUpdateURLHost.Name = "buttonUpdateURLHost";
            this.buttonUpdateURLHost.Size = new System.Drawing.Size(46, 20);
            this.buttonUpdateURLHost.TabIndex = 1;
            this.buttonUpdateURLHost.Text = "Update";
            this.buttonUpdateURLHost.UseVisualStyleBackColor = false;
            this.buttonUpdateURLHost.Click += new System.EventHandler(this.buttonUpdateURLHost_Click);
            // 
            // panelInterfaceTreeView
            // 
            this.panelInterfaceTreeView.Controls.Add(this.interfaceTreeView);
            this.panelInterfaceTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelInterfaceTreeView.Location = new System.Drawing.Point(0, 107);
            this.panelInterfaceTreeView.Margin = new System.Windows.Forms.Padding(0);
            this.panelInterfaceTreeView.Name = "panelInterfaceTreeView";
            this.panelInterfaceTreeView.Size = new System.Drawing.Size(215, 529);
            this.panelInterfaceTreeView.TabIndex = 1;
            // 
            // interfaceTreeView
            // 
            this.interfaceTreeView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.interfaceTreeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.interfaceTreeView.Cursor = System.Windows.Forms.Cursors.Default;
            this.interfaceTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.interfaceTreeView.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.interfaceTreeView.ForeColor = System.Drawing.Color.Silver;
            this.interfaceTreeView.Indent = 13;
            this.interfaceTreeView.Location = new System.Drawing.Point(0, 0);
            this.interfaceTreeView.Margin = new System.Windows.Forms.Padding(0);
            this.interfaceTreeView.Name = "interfaceTreeView";
            this.interfaceTreeView.Size = new System.Drawing.Size(215, 529);
            this.interfaceTreeView.TabIndex = 1;
            this.interfaceTreeView.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.interfaceTreeViewNode_Click);
            // 
            // tableLayoutPanelBodyContainer
            // 
            this.tableLayoutPanelBodyContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tableLayoutPanelBodyContainer.ColumnCount = 1;
            this.tableLayoutPanelBodyContainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelBodyContainer.Controls.Add(this.panelBodyHeaderContainer, 0, 0);
            this.tableLayoutPanelBodyContainer.Controls.Add(this.panelBodySectionContainer, 0, 1);
            this.tableLayoutPanelBodyContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelBodyContainer.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelBodyContainer.Margin = new System.Windows.Forms.Padding(0, 0, 5, 5);
            this.tableLayoutPanelBodyContainer.Name = "tableLayoutPanelBodyContainer";
            this.tableLayoutPanelBodyContainer.RowCount = 2;
            this.tableLayoutPanelBodyContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanelBodyContainer.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelBodyContainer.Size = new System.Drawing.Size(800, 641);
            this.tableLayoutPanelBodyContainer.TabIndex = 1;
            // 
            // panelBodyHeaderContainer
            // 
            this.panelBodyHeaderContainer.BackColor = System.Drawing.Color.Transparent;
            this.panelBodyHeaderContainer.Controls.Add(this.tableLayoutPanelBodyHeader);
            this.panelBodyHeaderContainer.Location = new System.Drawing.Point(0, 0);
            this.panelBodyHeaderContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelBodyHeaderContainer.Name = "panelBodyHeaderContainer";
            this.panelBodyHeaderContainer.Size = new System.Drawing.Size(800, 40);
            this.panelBodyHeaderContainer.TabIndex = 1;
            // 
            // tableLayoutPanelBodyHeader
            // 
            this.tableLayoutPanelBodyHeader.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.tableLayoutPanelBodyHeader.ColumnCount = 7;
            this.tableLayoutPanelBodyHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanelBodyHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanelBodyHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanelBodyHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanelBodyHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanelBodyHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.tableLayoutPanelBodyHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 106F));
            this.tableLayoutPanelBodyHeader.Controls.Add(this.labelUserId, 0, 0);
            this.tableLayoutPanelBodyHeader.Controls.Add(this.panelTextBoxUserId, 1, 0);
            this.tableLayoutPanelBodyHeader.Controls.Add(this.labelDeviceId, 2, 0);
            this.tableLayoutPanelBodyHeader.Controls.Add(this.panelTextBoxDeviceId, 3, 0);
            this.tableLayoutPanelBodyHeader.Controls.Add(this.labelAuthKey, 4, 0);
            this.tableLayoutPanelBodyHeader.Controls.Add(this.panelTextBoxAuthKey, 5, 0);
            this.tableLayoutPanelBodyHeader.Controls.Add(this.panelBodyHeaderButton, 6, 0);
            this.tableLayoutPanelBodyHeader.Location = new System.Drawing.Point(0, 10);
            this.tableLayoutPanelBodyHeader.Margin = new System.Windows.Forms.Padding(10, 0, 6, 0);
            this.tableLayoutPanelBodyHeader.Name = "tableLayoutPanelBodyHeader";
            this.tableLayoutPanelBodyHeader.RowCount = 1;
            this.tableLayoutPanelBodyHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 24F));
            this.tableLayoutPanelBodyHeader.Size = new System.Drawing.Size(746, 24);
            this.tableLayoutPanelBodyHeader.TabIndex = 1;
            // 
            // labelUserId
            // 
            this.labelUserId.AutoSize = true;
            this.labelUserId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelUserId.ForeColor = System.Drawing.Color.DarkGray;
            this.labelUserId.Location = new System.Drawing.Point(3, 0);
            this.labelUserId.Name = "labelUserId";
            this.labelUserId.Size = new System.Drawing.Size(54, 24);
            this.labelUserId.TabIndex = 1;
            this.labelUserId.Text = "User ID";
            this.labelUserId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelTextBoxUserId
            // 
            this.panelTextBoxUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelTextBoxUserId.Controls.Add(this.textBoxUserId);
            this.panelTextBoxUserId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTextBoxUserId.Location = new System.Drawing.Point(63, 3);
            this.panelTextBoxUserId.Margin = new System.Windows.Forms.Padding(3, 3, 0, 0);
            this.panelTextBoxUserId.Name = "panelTextBoxUserId";
            this.panelTextBoxUserId.Padding = new System.Windows.Forms.Padding(3);
            this.panelTextBoxUserId.Size = new System.Drawing.Size(87, 21);
            this.panelTextBoxUserId.TabIndex = 1;
            // 
            // textBoxUserId
            // 
            this.textBoxUserId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxUserId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxUserId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxUserId.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUserId.ForeColor = System.Drawing.Color.LightGray;
            this.textBoxUserId.Location = new System.Drawing.Point(3, 3);
            this.textBoxUserId.Name = "textBoxUserId";
            this.textBoxUserId.Size = new System.Drawing.Size(81, 15);
            this.textBoxUserId.TabIndex = 1;
            // 
            // labelDeviceId
            // 
            this.labelDeviceId.AutoSize = true;
            this.labelDeviceId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelDeviceId.ForeColor = System.Drawing.Color.DarkGray;
            this.labelDeviceId.Location = new System.Drawing.Point(153, 0);
            this.labelDeviceId.Name = "labelDeviceId";
            this.labelDeviceId.Size = new System.Drawing.Size(64, 24);
            this.labelDeviceId.TabIndex = 1;
            this.labelDeviceId.Text = "Device ID";
            this.labelDeviceId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelTextBoxDeviceId
            // 
            this.panelTextBoxDeviceId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelTextBoxDeviceId.Controls.Add(this.textBoxDeviceId);
            this.panelTextBoxDeviceId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTextBoxDeviceId.Location = new System.Drawing.Point(223, 3);
            this.panelTextBoxDeviceId.Margin = new System.Windows.Forms.Padding(3, 3, 0, 0);
            this.panelTextBoxDeviceId.Name = "panelTextBoxDeviceId";
            this.panelTextBoxDeviceId.Padding = new System.Windows.Forms.Padding(3);
            this.panelTextBoxDeviceId.Size = new System.Drawing.Size(117, 21);
            this.panelTextBoxDeviceId.TabIndex = 1;
            // 
            // textBoxDeviceId
            // 
            this.textBoxDeviceId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxDeviceId.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxDeviceId.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxDeviceId.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDeviceId.ForeColor = System.Drawing.Color.LightGray;
            this.textBoxDeviceId.Location = new System.Drawing.Point(3, 3);
            this.textBoxDeviceId.Name = "textBoxDeviceId";
            this.textBoxDeviceId.Size = new System.Drawing.Size(111, 15);
            this.textBoxDeviceId.TabIndex = 1;
            // 
            // labelAuthKey
            // 
            this.labelAuthKey.AutoSize = true;
            this.labelAuthKey.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelAuthKey.ForeColor = System.Drawing.Color.DarkGray;
            this.labelAuthKey.Location = new System.Drawing.Point(343, 0);
            this.labelAuthKey.Name = "labelAuthKey";
            this.labelAuthKey.Size = new System.Drawing.Size(64, 24);
            this.labelAuthKey.TabIndex = 1;
            this.labelAuthKey.Text = "Auth Key";
            this.labelAuthKey.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelTextBoxAuthKey
            // 
            this.panelTextBoxAuthKey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelTextBoxAuthKey.Controls.Add(this.textBoxAuthKey);
            this.panelTextBoxAuthKey.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTextBoxAuthKey.Location = new System.Drawing.Point(413, 3);
            this.panelTextBoxAuthKey.Margin = new System.Windows.Forms.Padding(3, 3, 0, 0);
            this.panelTextBoxAuthKey.Name = "panelTextBoxAuthKey";
            this.panelTextBoxAuthKey.Padding = new System.Windows.Forms.Padding(3);
            this.panelTextBoxAuthKey.Size = new System.Drawing.Size(227, 21);
            this.panelTextBoxAuthKey.TabIndex = 1;
            // 
            // textBoxAuthKey
            // 
            this.textBoxAuthKey.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxAuthKey.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxAuthKey.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxAuthKey.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAuthKey.ForeColor = System.Drawing.Color.LightGray;
            this.textBoxAuthKey.Location = new System.Drawing.Point(3, 3);
            this.textBoxAuthKey.Name = "textBoxAuthKey";
            this.textBoxAuthKey.Size = new System.Drawing.Size(221, 15);
            this.textBoxAuthKey.TabIndex = 1;
            // 
            // panelBodyHeaderButton
            // 
            this.panelBodyHeaderButton.Controls.Add(this.buttonApplyToRequest);
            this.panelBodyHeaderButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBodyHeaderButton.Location = new System.Drawing.Point(643, 3);
            this.panelBodyHeaderButton.Margin = new System.Windows.Forms.Padding(3, 3, 0, 0);
            this.panelBodyHeaderButton.Name = "panelBodyHeaderButton";
            this.panelBodyHeaderButton.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.panelBodyHeaderButton.Size = new System.Drawing.Size(103, 21);
            this.panelBodyHeaderButton.TabIndex = 1;
            // 
            // buttonApplyToRequest
            // 
            this.buttonApplyToRequest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(114)))), ((int)(((byte)(72)))));
            this.buttonApplyToRequest.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonApplyToRequest.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonApplyToRequest.FlatAppearance.BorderSize = 0;
            this.buttonApplyToRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonApplyToRequest.Font = new System.Drawing.Font("Segoe UI", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonApplyToRequest.ForeColor = System.Drawing.Color.White;
            this.buttonApplyToRequest.Location = new System.Drawing.Point(3, 0);
            this.buttonApplyToRequest.Margin = new System.Windows.Forms.Padding(0);
            this.buttonApplyToRequest.Name = "buttonApplyToRequest";
            this.buttonApplyToRequest.Size = new System.Drawing.Size(100, 21);
            this.buttonApplyToRequest.TabIndex = 1;
            this.buttonApplyToRequest.Text = "Apply to Request";
            this.buttonApplyToRequest.UseVisualStyleBackColor = false;
            this.buttonApplyToRequest.Click += new System.EventHandler(this.buttonApplyToRequest_Click);
            // 
            // panelBodySectionContainer
            // 
            this.panelBodySectionContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelBodySectionContainer.Controls.Add(this.tableLayoutPanelBodySection);
            this.panelBodySectionContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBodySectionContainer.Location = new System.Drawing.Point(0, 40);
            this.panelBodySectionContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelBodySectionContainer.Name = "panelBodySectionContainer";
            this.panelBodySectionContainer.Size = new System.Drawing.Size(800, 601);
            this.panelBodySectionContainer.TabIndex = 1;
            // 
            // tableLayoutPanelBodySection
            // 
            this.tableLayoutPanelBodySection.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.tableLayoutPanelBodySection.ColumnCount = 1;
            this.tableLayoutPanelBodySection.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanelBodySection.Controls.Add(this.tableLayoutPanelBodyEndpoint, 0, 0);
            this.tableLayoutPanelBodySection.Controls.Add(this.splitContainerBody, 0, 1);
            this.tableLayoutPanelBodySection.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelBodySection.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelBodySection.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelBodySection.Name = "tableLayoutPanelBodySection";
            this.tableLayoutPanelBodySection.RowCount = 2;
            this.tableLayoutPanelBodySection.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanelBodySection.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanelBodySection.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelBodySection.Size = new System.Drawing.Size(800, 601);
            this.tableLayoutPanelBodySection.TabIndex = 1;
            // 
            // tableLayoutPanelBodyEndpoint
            // 
            this.tableLayoutPanelBodyEndpoint.ColumnCount = 2;
            this.tableLayoutPanelBodyEndpoint.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelBodyEndpoint.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.tableLayoutPanelBodyEndpoint.Controls.Add(this.panelBodyHeaderEndpoint, 0, 0);
            this.tableLayoutPanelBodyEndpoint.Controls.Add(this.buttonSend, 1, 0);
            this.tableLayoutPanelBodyEndpoint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelBodyEndpoint.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelBodyEndpoint.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelBodyEndpoint.Name = "tableLayoutPanelBodyEndpoint";
            this.tableLayoutPanelBodyEndpoint.RowCount = 1;
            this.tableLayoutPanelBodyEndpoint.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanelBodyEndpoint.Size = new System.Drawing.Size(800, 40);
            this.tableLayoutPanelBodyEndpoint.TabIndex = 1;
            // 
            // panelBodyHeaderEndpoint
            // 
            this.panelBodyHeaderEndpoint.BackColor = System.Drawing.Color.Transparent;
            this.panelBodyHeaderEndpoint.Controls.Add(this.panelBodyHeaderEndpointBox);
            this.panelBodyHeaderEndpoint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBodyHeaderEndpoint.Location = new System.Drawing.Point(0, 5);
            this.panelBodyHeaderEndpoint.Margin = new System.Windows.Forms.Padding(0, 5, 0, 15);
            this.panelBodyHeaderEndpoint.Name = "panelBodyHeaderEndpoint";
            this.panelBodyHeaderEndpoint.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.panelBodyHeaderEndpoint.Size = new System.Drawing.Size(710, 40);
            this.panelBodyHeaderEndpoint.TabIndex = 1;
            // 
            // panelBodyHeaderEndpointBox
            // 
            this.panelBodyHeaderEndpointBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panelBodyHeaderEndpointBox.Controls.Add(this.textBoxEndpoint);
            this.panelBodyHeaderEndpointBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelBodyHeaderEndpointBox.Location = new System.Drawing.Point(0, 0);
            this.panelBodyHeaderEndpointBox.Margin = new System.Windows.Forms.Padding(0);
            this.panelBodyHeaderEndpointBox.Name = "panelBodyHeaderEndpointBox";
            this.panelBodyHeaderEndpointBox.Padding = new System.Windows.Forms.Padding(7);
            this.panelBodyHeaderEndpointBox.Size = new System.Drawing.Size(710, 30);
            this.panelBodyHeaderEndpointBox.TabIndex = 1;
            // 
            // textBoxEndpoint
            // 
            this.textBoxEndpoint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxEndpoint.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxEndpoint.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxEndpoint.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEndpoint.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.textBoxEndpoint.Location = new System.Drawing.Point(7, 7);
            this.textBoxEndpoint.Margin = new System.Windows.Forms.Padding(0);
            this.textBoxEndpoint.Name = "textBoxEndpoint";
            this.textBoxEndpoint.Size = new System.Drawing.Size(696, 16);
            this.textBoxEndpoint.TabIndex = 1;
            this.textBoxEndpoint.Text = "https://";
            // 
            // buttonSend
            // 
            this.buttonSend.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(124)))), ((int)(((byte)(229)))));
            this.buttonSend.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSend.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(124)))), ((int)(((byte)(229)))));
            this.buttonSend.FlatAppearance.BorderSize = 0;
            this.buttonSend.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(86)))), ((int)(((byte)(138)))));
            this.buttonSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSend.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSend.ForeColor = System.Drawing.Color.White;
            this.buttonSend.Location = new System.Drawing.Point(715, 5);
            this.buttonSend.Margin = new System.Windows.Forms.Padding(5);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(80, 30);
            this.buttonSend.TabIndex = 1;
            this.buttonSend.Text = "Send";
            this.buttonSend.UseVisualStyleBackColor = false;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // splitContainerBody
            // 
            this.splitContainerBody.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.splitContainerBody.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.splitContainerBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerBody.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(67)))), ((int)(((byte)(67)))));
            this.splitContainerBody.Location = new System.Drawing.Point(0, 40);
            this.splitContainerBody.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainerBody.Name = "splitContainerBody";
            // 
            // splitContainerBody.Panel1
            // 
            this.splitContainerBody.Panel1.Controls.Add(this.tableLayoutPanelRequestContainer);
            this.splitContainerBody.Panel1MinSize = 250;
            // 
            // splitContainerBody.Panel2
            // 
            this.splitContainerBody.Panel2.Controls.Add(this.tableLayoutPanelResponseContainer);
            this.splitContainerBody.Panel2MinSize = 250;
            this.splitContainerBody.Size = new System.Drawing.Size(800, 561);
            this.splitContainerBody.SplitterDistance = 340;
            this.splitContainerBody.TabIndex = 1;
            // 
            // tableLayoutPanelRequestContainer
            // 
            this.tableLayoutPanelRequestContainer.ColumnCount = 1;
            this.tableLayoutPanelRequestContainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestContainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelRequestContainer.Controls.Add(this.tableLayoutPanelRequestTabHeader, 0, 0);
            this.tableLayoutPanelRequestContainer.Controls.Add(this.panelRequestContainer, 0, 1);
            this.tableLayoutPanelRequestContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRequestContainer.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelRequestContainer.Name = "tableLayoutPanelRequestContainer";
            this.tableLayoutPanelRequestContainer.RowCount = 2;
            this.tableLayoutPanelRequestContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanelRequestContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestContainer.Size = new System.Drawing.Size(338, 559);
            this.tableLayoutPanelRequestContainer.TabIndex = 1;
            // 
            // tableLayoutPanelRequestTabHeader
            // 
            this.tableLayoutPanelRequestTabHeader.ColumnCount = 1;
            this.tableLayoutPanelRequestTabHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelRequestTabHeader.Controls.Add(this.panelRequestTabContainer, 0, 0);
            this.tableLayoutPanelRequestTabHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRequestTabHeader.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelRequestTabHeader.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelRequestTabHeader.Name = "tableLayoutPanelRequestTabHeader";
            this.tableLayoutPanelRequestTabHeader.RowCount = 1;
            this.tableLayoutPanelRequestTabHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabHeader.Size = new System.Drawing.Size(338, 30);
            this.tableLayoutPanelRequestTabHeader.TabIndex = 1;
            // 
            // panelRequestTabContainer
            // 
            this.panelRequestTabContainer.Controls.Add(this.buttonTabRequestSample);
            this.panelRequestTabContainer.Controls.Add(this.buttonTabRequestBeforeEncrypted);
            this.panelRequestTabContainer.Controls.Add(this.buttonTabRequestAfterEncrypted);
            this.panelRequestTabContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRequestTabContainer.Location = new System.Drawing.Point(0, 0);
            this.panelRequestTabContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelRequestTabContainer.Name = "panelRequestTabContainer";
            this.panelRequestTabContainer.Size = new System.Drawing.Size(338, 30);
            this.panelRequestTabContainer.TabIndex = 1;
            // 
            // buttonTabRequestSample
            // 
            this.buttonTabRequestSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.buttonTabRequestSample.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabRequestSample.FlatAppearance.BorderSize = 0;
            this.buttonTabRequestSample.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabRequestSample.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabRequestSample.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.buttonTabRequestSample.Location = new System.Drawing.Point(5, 7);
            this.buttonTabRequestSample.Margin = new System.Windows.Forms.Padding(0);
            this.buttonTabRequestSample.Name = "buttonTabRequestSample";
            this.buttonTabRequestSample.Size = new System.Drawing.Size(70, 23);
            this.buttonTabRequestSample.TabIndex = 1;
            this.buttonTabRequestSample.Text = "Sample";
            this.buttonTabRequestSample.UseVisualStyleBackColor = false;
            this.buttonTabRequestSample.Click += new System.EventHandler(this.buttonTabRequestSample_Click);
            // 
            // buttonTabRequestBeforeEncrypted
            // 
            this.buttonTabRequestBeforeEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.buttonTabRequestBeforeEncrypted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabRequestBeforeEncrypted.FlatAppearance.BorderSize = 0;
            this.buttonTabRequestBeforeEncrypted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabRequestBeforeEncrypted.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTabRequestBeforeEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
            this.buttonTabRequestBeforeEncrypted.Location = new System.Drawing.Point(77, 7);
            this.buttonTabRequestBeforeEncrypted.Margin = new System.Windows.Forms.Padding(0);
            this.buttonTabRequestBeforeEncrypted.Name = "buttonTabRequestBeforeEncrypted";
            this.buttonTabRequestBeforeEncrypted.Size = new System.Drawing.Size(110, 23);
            this.buttonTabRequestBeforeEncrypted.TabIndex = 1;
            this.buttonTabRequestBeforeEncrypted.Text = "Before Encrypted";
            this.buttonTabRequestBeforeEncrypted.UseVisualStyleBackColor = false;
            this.buttonTabRequestBeforeEncrypted.Click += new System.EventHandler(this.buttonTapRequestBeforeEncrypted_Click);
            // 
            // buttonTabRequestAfterEncrypted
            // 
            this.buttonTabRequestAfterEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.buttonTabRequestAfterEncrypted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabRequestAfterEncrypted.FlatAppearance.BorderSize = 0;
            this.buttonTabRequestAfterEncrypted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabRequestAfterEncrypted.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.buttonTabRequestAfterEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.buttonTabRequestAfterEncrypted.Location = new System.Drawing.Point(189, 7);
            this.buttonTabRequestAfterEncrypted.Margin = new System.Windows.Forms.Padding(0);
            this.buttonTabRequestAfterEncrypted.Name = "buttonTabRequestAfterEncrypted";
            this.buttonTabRequestAfterEncrypted.Size = new System.Drawing.Size(110, 23);
            this.buttonTabRequestAfterEncrypted.TabIndex = 1;
            this.buttonTabRequestAfterEncrypted.Text = "After Encrypted";
            this.buttonTabRequestAfterEncrypted.UseVisualStyleBackColor = false;
            this.buttonTabRequestAfterEncrypted.Click += new System.EventHandler(this.buttonTabRequestAfterEncrypted_Click);
            // 
            // panelRequestContainer
            // 
            this.panelRequestContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelRequestContainer.Controls.Add(this.panelRequestTabSample);
            this.panelRequestContainer.Controls.Add(this.panelRequestTabBeforeEncrypted);
            this.panelRequestContainer.Controls.Add(this.panelRequestTabAfterEncrypted);
            this.panelRequestContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRequestContainer.Location = new System.Drawing.Point(0, 30);
            this.panelRequestContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelRequestContainer.Name = "panelRequestContainer";
            this.panelRequestContainer.Size = new System.Drawing.Size(338, 529);
            this.panelRequestContainer.TabIndex = 1;
            // 
            // panelRequestTabSample
            // 
            this.panelRequestTabSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelRequestTabSample.Controls.Add(this.tableLayoutPanelRequestTabSample);
            this.panelRequestTabSample.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRequestTabSample.Location = new System.Drawing.Point(0, 0);
            this.panelRequestTabSample.Name = "panelRequestTabSample";
            this.panelRequestTabSample.Padding = new System.Windows.Forms.Padding(3);
            this.panelRequestTabSample.Size = new System.Drawing.Size(338, 529);
            this.panelRequestTabSample.TabIndex = 1;
            // 
            // tableLayoutPanelRequestTabSample
            // 
            this.tableLayoutPanelRequestTabSample.ColumnCount = 1;
            this.tableLayoutPanelRequestTabSample.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabSample.Controls.Add(this.labelSampleName, 0, 0);
            this.tableLayoutPanelRequestTabSample.Controls.Add(this.inputRequestTabSample, 0, 1);
            this.tableLayoutPanelRequestTabSample.Controls.Add(this.tableLayoutPanelRequestTabSampleFooter, 0, 2);
            this.tableLayoutPanelRequestTabSample.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRequestTabSample.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanelRequestTabSample.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelRequestTabSample.Name = "tableLayoutPanelRequestTabSample";
            this.tableLayoutPanelRequestTabSample.RowCount = 3;
            this.tableLayoutPanelRequestTabSample.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanelRequestTabSample.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabSample.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanelRequestTabSample.Size = new System.Drawing.Size(332, 523);
            this.tableLayoutPanelRequestTabSample.TabIndex = 1;
            // 
            // labelSampleName
            // 
            this.labelSampleName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.labelSampleName.AutoSize = true;
            this.labelSampleName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.labelSampleName.ForeColor = System.Drawing.Color.LightGray;
            this.labelSampleName.Location = new System.Drawing.Point(5, 7);
            this.labelSampleName.Margin = new System.Windows.Forms.Padding(5, 7, 5, 7);
            this.labelSampleName.Name = "labelSampleName";
            this.labelSampleName.Size = new System.Drawing.Size(0, 15);
            this.labelSampleName.TabIndex = 1;
            // 
            // inputRequestTabSample
            // 
            this.inputRequestTabSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.inputRequestTabSample.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.inputRequestTabSample.Dock = System.Windows.Forms.DockStyle.Fill;
            this.inputRequestTabSample.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.inputRequestTabSample.ForeColor = System.Drawing.Color.PaleTurquoise;
            this.inputRequestTabSample.Location = new System.Drawing.Point(3, 33);
            this.inputRequestTabSample.Name = "inputRequestTabSample";
            this.inputRequestTabSample.Size = new System.Drawing.Size(326, 453);
            this.inputRequestTabSample.TabIndex = 1;
            this.inputRequestTabSample.Text = "";
            this.inputRequestTabSample.WordWrap = false;
            // 
            // tableLayoutPanelRequestTabSampleFooter
            // 
            this.tableLayoutPanelRequestTabSampleFooter.ColumnCount = 2;
            this.tableLayoutPanelRequestTabSampleFooter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRequestTabSampleFooter.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRequestTabSampleFooter.Controls.Add(this.buttonSampleSave, 0, 0);
            this.tableLayoutPanelRequestTabSampleFooter.Controls.Add(this.buttonSampleReset, 1, 0);
            this.tableLayoutPanelRequestTabSampleFooter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRequestTabSampleFooter.Location = new System.Drawing.Point(3, 492);
            this.tableLayoutPanelRequestTabSampleFooter.Name = "tableLayoutPanelRequestTabSampleFooter";
            this.tableLayoutPanelRequestTabSampleFooter.RowCount = 1;
            this.tableLayoutPanelRequestTabSampleFooter.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabSampleFooter.Size = new System.Drawing.Size(326, 28);
            this.tableLayoutPanelRequestTabSampleFooter.TabIndex = 1;
            // 
            // buttonSampleSave
            // 
            this.buttonSampleSave.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.buttonSampleSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(114)))), ((int)(((byte)(72)))));
            this.buttonSampleSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSampleSave.FlatAppearance.BorderSize = 0;
            this.buttonSampleSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSampleSave.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSampleSave.ForeColor = System.Drawing.Color.White;
            this.buttonSampleSave.Location = new System.Drawing.Point(100, 3);
            this.buttonSampleSave.Name = "buttonSampleSave";
            this.buttonSampleSave.Size = new System.Drawing.Size(60, 22);
            this.buttonSampleSave.TabIndex = 1;
            this.buttonSampleSave.Text = "Save";
            this.buttonSampleSave.UseVisualStyleBackColor = false;
            this.buttonSampleSave.Click += new System.EventHandler(this.buttonSampleSave_Click);
            // 
            // buttonSampleReset
            // 
            this.buttonSampleReset.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.buttonSampleReset.BackColor = System.Drawing.Color.Gray;
            this.buttonSampleReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSampleReset.FlatAppearance.BorderSize = 0;
            this.buttonSampleReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSampleReset.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSampleReset.ForeColor = System.Drawing.Color.White;
            this.buttonSampleReset.Location = new System.Drawing.Point(166, 3);
            this.buttonSampleReset.Name = "buttonSampleReset";
            this.buttonSampleReset.Size = new System.Drawing.Size(60, 22);
            this.buttonSampleReset.TabIndex = 1;
            this.buttonSampleReset.Text = "Reset";
            this.buttonSampleReset.UseVisualStyleBackColor = false;
            this.buttonSampleReset.Click += new System.EventHandler(this.buttonSampleReset_Click);
            // 
            // panelRequestTabBeforeEncrypted
            // 
            this.panelRequestTabBeforeEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelRequestTabBeforeEncrypted.Controls.Add(this.tableLayoutPanelRequestTabBeforeEncrypted);
            this.panelRequestTabBeforeEncrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRequestTabBeforeEncrypted.Location = new System.Drawing.Point(0, 0);
            this.panelRequestTabBeforeEncrypted.Name = "panelRequestTabBeforeEncrypted";
            this.panelRequestTabBeforeEncrypted.Size = new System.Drawing.Size(338, 529);
            this.panelRequestTabBeforeEncrypted.TabIndex = 1;
            // 
            // tableLayoutPanelRequestTabBeforeEncrypted
            // 
            this.tableLayoutPanelRequestTabBeforeEncrypted.ColumnCount = 1;
            this.tableLayoutPanelRequestTabBeforeEncrypted.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabBeforeEncrypted.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanelRequestTabBeforeEncrypted.Controls.Add(this.inputRequestTabBeforeEncrypted, 0, 1);
            this.tableLayoutPanelRequestTabBeforeEncrypted.Controls.Add(this.tableLayoutPanelRequestTabBeforeEncryptedHeader, 0, 0);
            this.tableLayoutPanelRequestTabBeforeEncrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRequestTabBeforeEncrypted.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelRequestTabBeforeEncrypted.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelRequestTabBeforeEncrypted.Name = "tableLayoutPanelRequestTabBeforeEncrypted";
            this.tableLayoutPanelRequestTabBeforeEncrypted.RowCount = 2;
            this.tableLayoutPanelRequestTabBeforeEncrypted.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanelRequestTabBeforeEncrypted.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabBeforeEncrypted.Size = new System.Drawing.Size(338, 529);
            this.tableLayoutPanelRequestTabBeforeEncrypted.TabIndex = 1;
            // 
            // inputRequestTabBeforeEncrypted
            // 
            this.inputRequestTabBeforeEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.inputRequestTabBeforeEncrypted.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.inputRequestTabBeforeEncrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.inputRequestTabBeforeEncrypted.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.inputRequestTabBeforeEncrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(170)))));
            this.inputRequestTabBeforeEncrypted.Location = new System.Drawing.Point(6, 36);
            this.inputRequestTabBeforeEncrypted.Margin = new System.Windows.Forms.Padding(6);
            this.inputRequestTabBeforeEncrypted.Name = "inputRequestTabBeforeEncrypted";
            this.inputRequestTabBeforeEncrypted.Size = new System.Drawing.Size(326, 487);
            this.inputRequestTabBeforeEncrypted.TabIndex = 1;
            this.inputRequestTabBeforeEncrypted.Text = "";
            this.inputRequestTabBeforeEncrypted.WordWrap = false;
            // 
            // tableLayoutPanelRequestTabBeforeEncryptedHeader
            // 
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.ColumnCount = 2;
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.Controls.Add(this.buttonBrowseFile, 1, 0);
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.Controls.Add(this.buttonLoadSample, 0, 0);
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.Location = new System.Drawing.Point(0, 6);
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.Margin = new System.Windows.Forms.Padding(0, 6, 6, 0);
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.Name = "tableLayoutPanelRequestTabBeforeEncryptedHeader";
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.RowCount = 1;
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.Size = new System.Drawing.Size(332, 24);
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.TabIndex = 1;
            // 
            // buttonBrowseFile
            // 
            this.buttonBrowseFile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonBrowseFile.BackColor = System.Drawing.Color.Gray;
            this.buttonBrowseFile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBrowseFile.FlatAppearance.BorderSize = 0;
            this.buttonBrowseFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBrowseFile.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBrowseFile.ForeColor = System.Drawing.Color.White;
            this.buttonBrowseFile.Location = new System.Drawing.Point(252, 2);
            this.buttonBrowseFile.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.buttonBrowseFile.Name = "buttonBrowseFile";
            this.buttonBrowseFile.Size = new System.Drawing.Size(74, 22);
            this.buttonBrowseFile.TabIndex = 1;
            this.buttonBrowseFile.Text = "Browse File";
            this.buttonBrowseFile.UseVisualStyleBackColor = false;
            this.buttonBrowseFile.Visible = false;
            this.buttonBrowseFile.Click += new System.EventHandler(this.buttonBrowseFile_Click);
            // 
            // buttonLoadSample
            // 
            this.buttonLoadSample.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonLoadSample.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(114)))), ((int)(((byte)(72)))));
            this.buttonLoadSample.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonLoadSample.FlatAppearance.BorderSize = 0;
            this.buttonLoadSample.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLoadSample.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLoadSample.ForeColor = System.Drawing.Color.White;
            this.buttonLoadSample.Location = new System.Drawing.Point(6, 2);
            this.buttonLoadSample.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.buttonLoadSample.Name = "buttonLoadSample";
            this.buttonLoadSample.Size = new System.Drawing.Size(90, 22);
            this.buttonLoadSample.TabIndex = 1;
            this.buttonLoadSample.Text = "Load Sample";
            this.buttonLoadSample.UseVisualStyleBackColor = false;
            this.buttonLoadSample.Click += new System.EventHandler(this.buttonLoadSample_Click);
            // 
            // panelRequestTabAfterEncrypted
            // 
            this.panelRequestTabAfterEncrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelRequestTabAfterEncrypted.Controls.Add(this.inputRequestTabAfterEncrypted);
            this.panelRequestTabAfterEncrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelRequestTabAfterEncrypted.Location = new System.Drawing.Point(0, 0);
            this.panelRequestTabAfterEncrypted.Name = "panelRequestTabAfterEncrypted";
            this.panelRequestTabAfterEncrypted.Padding = new System.Windows.Forms.Padding(6);
            this.panelRequestTabAfterEncrypted.Size = new System.Drawing.Size(338, 529);
            this.panelRequestTabAfterEncrypted.TabIndex = 1;
            // 
            // inputRequestTabAfterEncrypted
            // 
            this.inputRequestTabAfterEncrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.inputRequestTabAfterEncrypted.Location = new System.Drawing.Point(6, 6);
            this.inputRequestTabAfterEncrypted.Margin = new System.Windows.Forms.Padding(0);
            this.inputRequestTabAfterEncrypted.MinimumSize = new System.Drawing.Size(20, 20);
            this.inputRequestTabAfterEncrypted.Name = "inputRequestTabAfterEncrypted";
            this.inputRequestTabAfterEncrypted.Size = new System.Drawing.Size(326, 517);
            this.inputRequestTabAfterEncrypted.TabIndex = 1;
            // 
            // tableLayoutPanelResponseContainer
            // 
            this.tableLayoutPanelResponseContainer.ColumnCount = 1;
            this.tableLayoutPanelResponseContainer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelResponseContainer.Controls.Add(this.panelResponseTabContainer, 0, 0);
            this.tableLayoutPanelResponseContainer.Controls.Add(this.panelResponseContainer, 0, 1);
            this.tableLayoutPanelResponseContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanelResponseContainer.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanelResponseContainer.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanelResponseContainer.Name = "tableLayoutPanelResponseContainer";
            this.tableLayoutPanelResponseContainer.RowCount = 2;
            this.tableLayoutPanelResponseContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tableLayoutPanelResponseContainer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanelResponseContainer.Size = new System.Drawing.Size(454, 559);
            this.tableLayoutPanelResponseContainer.TabIndex = 1;
            // 
            // panelResponseTabContainer
            // 
            this.panelResponseTabContainer.Controls.Add(this.buttonTabResponseBeforeDecrypted);
            this.panelResponseTabContainer.Controls.Add(this.buttonTabResponseAfterDecrypted);
            this.panelResponseTabContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelResponseTabContainer.Location = new System.Drawing.Point(0, 0);
            this.panelResponseTabContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelResponseTabContainer.Name = "panelResponseTabContainer";
            this.panelResponseTabContainer.Size = new System.Drawing.Size(454, 30);
            this.panelResponseTabContainer.TabIndex = 1;
            // 
            // buttonTabResponseBeforeDecrypted
            // 
            this.buttonTabResponseBeforeDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.buttonTabResponseBeforeDecrypted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabResponseBeforeDecrypted.FlatAppearance.BorderSize = 0;
            this.buttonTabResponseBeforeDecrypted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabResponseBeforeDecrypted.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.buttonTabResponseBeforeDecrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(170)))), ((int)(((byte)(170)))));
            this.buttonTabResponseBeforeDecrypted.Location = new System.Drawing.Point(5, 7);
            this.buttonTabResponseBeforeDecrypted.Margin = new System.Windows.Forms.Padding(0);
            this.buttonTabResponseBeforeDecrypted.Name = "buttonTabResponseBeforeDecrypted";
            this.buttonTabResponseBeforeDecrypted.Size = new System.Drawing.Size(112, 23);
            this.buttonTabResponseBeforeDecrypted.TabIndex = 1;
            this.buttonTabResponseBeforeDecrypted.Text = "Before Decrypted";
            this.buttonTabResponseBeforeDecrypted.UseVisualStyleBackColor = false;
            this.buttonTabResponseBeforeDecrypted.Click += new System.EventHandler(this.buttonTabResponseBeforeDecrypted_Click);
            // 
            // buttonTabResponseAfterDecrypted
            // 
            this.buttonTabResponseAfterDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.buttonTabResponseAfterDecrypted.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonTabResponseAfterDecrypted.FlatAppearance.BorderSize = 0;
            this.buttonTabResponseAfterDecrypted.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTabResponseAfterDecrypted.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.buttonTabResponseAfterDecrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(189)))), ((int)(((byte)(107)))), ((int)(((byte)(73)))));
            this.buttonTabResponseAfterDecrypted.Location = new System.Drawing.Point(119, 7);
            this.buttonTabResponseAfterDecrypted.Margin = new System.Windows.Forms.Padding(0);
            this.buttonTabResponseAfterDecrypted.Name = "buttonTabResponseAfterDecrypted";
            this.buttonTabResponseAfterDecrypted.Size = new System.Drawing.Size(112, 23);
            this.buttonTabResponseAfterDecrypted.TabIndex = 1;
            this.buttonTabResponseAfterDecrypted.Text = "After Decrypted";
            this.buttonTabResponseAfterDecrypted.UseVisualStyleBackColor = false;
            this.buttonTabResponseAfterDecrypted.Click += new System.EventHandler(this.buttonTabResponseAfterDecrypted_Click);
            // 
            // panelResponseContainer
            // 
            this.panelResponseContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelResponseContainer.Controls.Add(this.panelResponseTabAfterDecrypted);
            this.panelResponseContainer.Controls.Add(this.panelResponseTabBeforeDecrypted);
            this.panelResponseContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelResponseContainer.Location = new System.Drawing.Point(0, 30);
            this.panelResponseContainer.Margin = new System.Windows.Forms.Padding(0);
            this.panelResponseContainer.Name = "panelResponseContainer";
            this.panelResponseContainer.Size = new System.Drawing.Size(454, 529);
            this.panelResponseContainer.TabIndex = 1;
            // 
            // panelResponseTabAfterDecrypted
            // 
            this.panelResponseTabAfterDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelResponseTabAfterDecrypted.Controls.Add(this.outputResponseTabAfterDecrypted);
            this.panelResponseTabAfterDecrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelResponseTabAfterDecrypted.Location = new System.Drawing.Point(0, 0);
            this.panelResponseTabAfterDecrypted.Name = "panelResponseTabAfterDecrypted";
            this.panelResponseTabAfterDecrypted.Padding = new System.Windows.Forms.Padding(6);
            this.panelResponseTabAfterDecrypted.Size = new System.Drawing.Size(454, 529);
            this.panelResponseTabAfterDecrypted.TabIndex = 1;
            // 
            // outputResponseTabAfterDecrypted
            // 
            this.outputResponseTabAfterDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.outputResponseTabAfterDecrypted.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.outputResponseTabAfterDecrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.outputResponseTabAfterDecrypted.Font = new System.Drawing.Font("Consolas", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.outputResponseTabAfterDecrypted.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(220)))), ((int)(((byte)(170)))));
            this.outputResponseTabAfterDecrypted.Location = new System.Drawing.Point(6, 6);
            this.outputResponseTabAfterDecrypted.Margin = new System.Windows.Forms.Padding(6);
            this.outputResponseTabAfterDecrypted.Name = "outputResponseTabAfterDecrypted";
            this.outputResponseTabAfterDecrypted.ReadOnly = true;
            this.outputResponseTabAfterDecrypted.Size = new System.Drawing.Size(442, 517);
            this.outputResponseTabAfterDecrypted.TabIndex = 1;
            this.outputResponseTabAfterDecrypted.Text = "";
            this.outputResponseTabAfterDecrypted.WordWrap = false;
            // 
            // panelResponseTabBeforeDecrypted
            // 
            this.panelResponseTabBeforeDecrypted.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.panelResponseTabBeforeDecrypted.Controls.Add(this.outputResponseTabBeforeDecrypted);
            this.panelResponseTabBeforeDecrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelResponseTabBeforeDecrypted.Location = new System.Drawing.Point(0, 0);
            this.panelResponseTabBeforeDecrypted.Name = "panelResponseTabBeforeDecrypted";
            this.panelResponseTabBeforeDecrypted.Padding = new System.Windows.Forms.Padding(6);
            this.panelResponseTabBeforeDecrypted.Size = new System.Drawing.Size(454, 529);
            this.panelResponseTabBeforeDecrypted.TabIndex = 1;
            // 
            // outputResponseTabBeforeDecrypted
            // 
            this.outputResponseTabBeforeDecrypted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.outputResponseTabBeforeDecrypted.Location = new System.Drawing.Point(6, 6);
            this.outputResponseTabBeforeDecrypted.MinimumSize = new System.Drawing.Size(20, 20);
            this.outputResponseTabBeforeDecrypted.Name = "outputResponseTabBeforeDecrypted";
            this.outputResponseTabBeforeDecrypted.Size = new System.Drawing.Size(442, 517);
            this.outputResponseTabBeforeDecrypted.TabIndex = 1;
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1024, 641);
            this.Controls.Add(this.splitContainerMain);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "MainForm";
            this.Text = "KMA PDI - I/F TESTER";
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.splitContainerMain.Panel1.ResumeLayout(false);
            this.splitContainerMain.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerMain)).EndInit();
            this.splitContainerMain.ResumeLayout(false);
            this.panelInterfaceTypeContainer.ResumeLayout(false);
            this.tableLayoutPanelInterfaceContainer.ResumeLayout(false);
            this.panelInterfaceTypeHeader.ResumeLayout(false);
            this.tableLayoutPanelInterfaceType.ResumeLayout(false);
            this.panelInterfaceTabContainer.ResumeLayout(false);
            this.panelInterfaceTabIncoming.ResumeLayout(false);
            this.panelInterfaceTabOutgoing.ResumeLayout(false);
            this.panelInterfaceTypeBody.ResumeLayout(false);
            this.tableLayoutPanelIncomingURLHost.ResumeLayout(false);
            this.panelIncomingURLHost.ResumeLayout(false);
            this.panelIncomingURLHost.PerformLayout();
            this.panelInterfaceTreeView.ResumeLayout(false);
            this.tableLayoutPanelBodyContainer.ResumeLayout(false);
            this.panelBodyHeaderContainer.ResumeLayout(false);
            this.tableLayoutPanelBodyHeader.ResumeLayout(false);
            this.tableLayoutPanelBodyHeader.PerformLayout();
            this.panelTextBoxUserId.ResumeLayout(false);
            this.panelTextBoxUserId.PerformLayout();
            this.panelTextBoxDeviceId.ResumeLayout(false);
            this.panelTextBoxDeviceId.PerformLayout();
            this.panelTextBoxAuthKey.ResumeLayout(false);
            this.panelTextBoxAuthKey.PerformLayout();
            this.panelBodyHeaderButton.ResumeLayout(false);
            this.panelBodySectionContainer.ResumeLayout(false);
            this.tableLayoutPanelBodySection.ResumeLayout(false);
            this.tableLayoutPanelBodyEndpoint.ResumeLayout(false);
            this.panelBodyHeaderEndpoint.ResumeLayout(false);
            this.panelBodyHeaderEndpointBox.ResumeLayout(false);
            this.panelBodyHeaderEndpointBox.PerformLayout();
            this.splitContainerBody.Panel1.ResumeLayout(false);
            this.splitContainerBody.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerBody)).EndInit();
            this.splitContainerBody.ResumeLayout(false);
            this.tableLayoutPanelRequestContainer.ResumeLayout(false);
            this.tableLayoutPanelRequestTabHeader.ResumeLayout(false);
            this.panelRequestTabContainer.ResumeLayout(false);
            this.panelRequestContainer.ResumeLayout(false);
            this.panelRequestTabSample.ResumeLayout(false);
            this.tableLayoutPanelRequestTabSample.ResumeLayout(false);
            this.tableLayoutPanelRequestTabSample.PerformLayout();
            this.tableLayoutPanelRequestTabSampleFooter.ResumeLayout(false);
            this.panelRequestTabBeforeEncrypted.ResumeLayout(false);
            this.tableLayoutPanelRequestTabBeforeEncrypted.ResumeLayout(false);
            this.tableLayoutPanelRequestTabBeforeEncryptedHeader.ResumeLayout(false);
            this.panelRequestTabAfterEncrypted.ResumeLayout(false);
            this.tableLayoutPanelResponseContainer.ResumeLayout(false);
            this.panelResponseTabContainer.ResumeLayout(false);
            this.panelResponseContainer.ResumeLayout(false);
            this.panelResponseTabAfterDecrypted.ResumeLayout(false);
            this.panelResponseTabBeforeDecrypted.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion
		
		private System.Windows.Forms.SplitContainer splitContainerMain;
		private Panel panelInterfaceTypeContainer;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanelInterfaceContainer;
		private Panel panelInterfaceTypeHeader;
		private System.Windows.Forms.Panel panelInterfaceTypeBody;
		private Panel panelInterfaceTreeView;
		private Panel panelInterfaceTabContainer;
		private Panel panelInterfaceTabIncoming;
		private Panel panelInterfaceTabOutgoing;
		private TableLayoutPanel tableLayoutPanelInterfaceType;
		private Button buttonTabIncoming;
		private Button buttonTabOutgoing;
		private TableLayoutPanel tableLayoutPanelIncomingURLHost;
		private Panel panelIncomingURLHost;
		private TextBox textBoxURLHost;
		private Button buttonUpdateURLHost;
		private Button buttonTabIncomingLocal;
		private Button buttonTabIncomingStage;
		private Button buttonTabIncomingProd;
		private Button buttonTabOutgoingStage;
		private Button buttonTabOutgoingProd;
		private System.Windows.Forms.TreeView interfaceTreeView;
		private TableLayoutPanel tableLayoutPanelBodyContainer;
		private Panel panelBodyHeaderContainer;
		private TableLayoutPanel tableLayoutPanelBodyHeader;
		private Label labelUserId;
		private Panel panelTextBoxUserId;
		private TextBox textBoxUserId;
		private Label labelDeviceId;
		private Panel panelTextBoxDeviceId;
		private TextBox textBoxDeviceId;
		private Label labelAuthKey;
		private Panel panelTextBoxAuthKey;
		private TextBox textBoxAuthKey;
		private Panel panelBodyHeaderButton;
		private Button buttonApplyToRequest;
		private Panel panelBodySectionContainer;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanelBodySection;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanelBodyEndpoint;
		private System.Windows.Forms.Panel panelBodyHeaderEndpoint;
		private System.Windows.Forms.Panel panelBodyHeaderEndpointBox;
		private System.Windows.Forms.TextBox textBoxEndpoint;
		private System.Windows.Forms.Button buttonSend;
		private System.Windows.Forms.SplitContainer splitContainerBody;
		private TableLayoutPanel tableLayoutPanelRequestContainer;
		private Panel panelRequestTabContainer;
		private Button buttonTabRequestSample;
		private Button buttonTabRequestBeforeEncrypted;
		private Button buttonTabRequestAfterEncrypted;
		private Panel panelRequestContainer;
		private Panel panelRequestTabSample;
		private TableLayoutPanel tableLayoutPanelRequestTabSample;
		private Label labelSampleName;
		private RichTextBox inputRequestTabSample;
		private TableLayoutPanel tableLayoutPanelRequestTabSampleFooter;
		private Button buttonSampleSave;
		private Button buttonSampleReset;
		private Panel panelRequestTabBeforeEncrypted;
		private TableLayoutPanel tableLayoutPanelRequestTabBeforeEncrypted;
		private RichTextBox inputRequestTabBeforeEncrypted;
		private TableLayoutPanel tableLayoutPanelRequestTabBeforeEncryptedHeader;
		private Button buttonLoadSample;
		private Button buttonBrowseFile;
		private Panel panelRequestTabAfterEncrypted;
		private TableLayoutPanel tableLayoutPanelRequestTabHeader;
		private WebBrowser inputRequestTabAfterEncrypted;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanelResponseContainer;
		private Panel panelResponseTabContainer;
		private Button buttonTabResponseBeforeDecrypted;
		private Button buttonTabResponseAfterDecrypted;
		private Panel panelResponseContainer;
		private Panel panelResponseTabAfterDecrypted;
		private RichTextBox outputResponseTabAfterDecrypted;
		private Panel panelResponseTabBeforeDecrypted;
		private WebBrowser outputResponseTabBeforeDecrypted;
		private OpenFileDialog openFileDialog;
		private SaveFileDialog saveFileDialog;
	}
}

