﻿using System;
using System.Collections.Generic;
using System.Web;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

/// <summary>
/// Summary description for JsonparserHelper
/// </summary>
public class json_helper
{
	private JObject parser;
	public int iColCount;
	public json_helper(string strData)
	{
		parser = JObject.Parse(strData);
		iColCount = parser.Count;
	}

	/// <summary>
	/// get string value for json object name
	/// </summary>
	/// <param name="sName">json object name to search value</param>
	/// <returns>json object string value</returns>
	public string GetJsonValue(string sName)
	{
		string sResult = string.Empty;

		try
		{
			sResult = parser.GetValue(sName).ToString();
		}
		catch (Exception ex)
		{
			string error = ex.Message;
		}

		return sResult;
	}

	/// <summary>
	/// get json object list for json object name
	/// </summary>
	/// <param name="sName">json object name to search</param>
	/// <returns>json object list</returns>
	public List<string> GetJsonObject(string sName)
	{
		List<string> listResult = new List<string>();

		try
		{
			// check value type
			var jsonCollection = JArray.Parse(GetJsonValue(sName));

			foreach (var jsonObject in jsonCollection)
			{
				listResult.Add(jsonObject.ToString());
			}
		}
		catch (Exception ex)
		{
			string sError = ex.Message;
		}

		return listResult;
	}

	/// <summary>
	/// get dictionary format : {"alpa" : {"a":"b", "c":"d", "e":"f"}}
	/// </summary>
	/// <param name="sName"></param>
	/// <returns></returns>
	public Dictionary<string, string> GetJsonCollectionValue(string sName)
	{
		Dictionary<string, string> dicObj = null;
		try
		{
			dicObj = JsonConvert.DeserializeObject<Dictionary<string, string>>(parser.GetValue(sName).ToString());
		}
		catch (Exception ex)
		{
			dicObj = null;
		}

		return dicObj;
	}
}
