﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.IO;
using System.Security.Cryptography;

/// <summary>
/// Summary description for encode
/// </summary>
public class encode
{
	public encode()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	#region "TDES Algorithm"

	private static byte[] bKey = new byte[24];
	private static byte[] bIV = new byte[8];

	public static string EncryptTdes(string sDecoded)
	{
		SetKeyAndIv();

		string sReturn = string.Empty;

		try
		{
			sReturn = Convert.ToBase64String(Encrypt(System.Text.Encoding.Unicode.GetBytes(sDecoded), bKey, bIV));
		}
		catch (Exception ex)
		{
			sReturn = "Error: " + ex.Message;
		}

		return sReturn;
	}

	public static string DecryptTdes(string sEncoded)
	{
		SetKeyAndIv();

		string sReturn = string.Empty;

		try
		{
			sReturn = System.Text.Encoding.Unicode.GetString(Decrypt(Convert.FromBase64String(sEncoded), bKey, bIV));
		}
		catch (Exception ex)
		{
			sReturn = "Error: " + ex.Message;
		}

		return sReturn;
	}

	private static void SetKeyAndIv()
	{
		bKey[0] = 166;
		bKey[1] = 39;
		bKey[2] = 84;
		bKey[3] = 13;
		bKey[4] = 253;
		bKey[5] = 200;
		bKey[6] = 26;
		bKey[7] = 12;
		bKey[8] = 87;
		bKey[9] = 98;
		bKey[10] = 163;
		bKey[11] = 250;
		bKey[12] = 211;
		bKey[13] = 192;
		bKey[14] = 234;
		bKey[15] = 39;
		bKey[16] = 128;
		bKey[17] = 183;
		bKey[18] = 160;
		bKey[19] = 130;
		bKey[20] = 202;
		bKey[21] = 244;
		bKey[22] = 246;
		bKey[23] = 105;

		bIV[0] = 46;
		bIV[1] = 206;
		bIV[2] = 27;
		bIV[3] = 64;
		bIV[4] = 144;
		bIV[5] = 9;
		bIV[6] = 87;
		bIV[7] = 34;
	}

	// Encrypt a byte array into a byte array using a key and an IV 
	private static byte[] Encrypt(byte[] clearData, byte[] Key, byte[] IV)
	{
		// Create a MemoryStream to accept the encrypted bytes 
		MemoryStream ms = new MemoryStream();

		// Create a symmetric algorithm. 
		TripleDES alg = TripleDES.Create();

		// Set attributes
		alg.Key = Key;
		alg.IV = IV;
		alg.Mode = CipherMode.CBC;
		alg.Padding = PaddingMode.PKCS7;

		// Create a CryptoStream 
		CryptoStream cs = new CryptoStream(ms, alg.CreateEncryptor(), CryptoStreamMode.Write);

		// Write the data and make it do the encryption 
		cs.Write(clearData, 0, clearData.Length);

		// Close the crypto stream (or do FlushFinalBlock). 
		cs.Close();

		// Get the encrypted data from the MemoryStream.
		byte[] encryptedData = ms.ToArray();

		return encryptedData;
	}

	// Decrypt a byte array into a byte array using a key and an IV 
	private static byte[] Decrypt(byte[] cipherData, byte[] Key, byte[] IV)
	{
		// Create a MemoryStream that is going to accept the decrypted bytes 
		MemoryStream ms = new MemoryStream();

		// Create a symmetric algorithm. 
		TripleDES alg = TripleDES.Create();

		// Set attributes.
		alg.Key = Key;
		alg.IV = IV;
		alg.Mode = CipherMode.CBC;
		alg.Padding = PaddingMode.PKCS7;

		// Create a CryptoStream.
		CryptoStream cs = new CryptoStream(ms,
			alg.CreateDecryptor(), CryptoStreamMode.Write);

		// Write the data and make it do the decryption 
		cs.Write(cipherData, 0, cipherData.Length);

		// Close the crypto stream (or do FlushFinalBlock). 
		cs.Close();

		// Get the decrypted data from the MemoryStream. 
		byte[] decryptedData = ms.ToArray();

		return decryptedData;
	}

	#endregion

	public static string CheckTimestamp(string sREQTime)
	{
		string sResult = "N";

		try
		{
			double nREQTime = Convert.ToDouble(sREQTime.Replace("-", "").Replace(":", "").Replace(" ", ""));

			double nRESTime = Convert.ToDouble(DateTime.UtcNow.ToString("yyyyMMddHHmmss"));

			if (Math.Abs(nRESTime - nREQTime) < 10000)
			{
				sResult = "Y";
			}
		}
		catch (Exception ex)
		{
			string sError = ex.Message;
		}

		return sResult;
	}
}