﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Windows.Forms;
using System.Collections.Specialized;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

/// <summary>
/// Summary description for interface_tester
/// </summary>
public class interface_tester
{
	protected object SaveFileDialog;

	public interface_tester()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	/// <summary>
	/// Get string from text file
	/// </summary>
	/// <param name="fileName"></param>
	/// <returns></returns>
	public static string GetTextFromFile(string fileName)
	{
		string result = string.Empty;
		string filePath = "../../samples/" + fileName;
		string textData = INTERFACE_TESTER.MainForm._templateText;

		if (!File.Exists(filePath) && !string.IsNullOrEmpty(textData))
		{
			using (StreamWriter streamWriter = File.CreateText(filePath)) 
            {
                streamWriter.WriteLine(textData);
            }
		}
		
		if (File.Exists(filePath))
		{
			using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
			{
				using (StreamReader streamReader = new StreamReader(fileStream))
				{
					result = streamReader.ReadToEnd();
				}
			}
		}

		return result;
	}

	/// <summary>
	/// Get JSON node from file
	/// </summary>
	/// <param name="fileName"></param>
	/// <returns></returns>
	public static string GetJsonFromFile(string fileName)
	{
		string result = string.Empty;
		string filePath = "../../" + fileName;

		if (File.Exists(filePath))
		{
			using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
			{
				using (StreamReader streamReader = new StreamReader(fileStream))
				{
					result = streamReader.ReadToEnd().Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
				}
			}
		}

		return result;
	}

	/// <summary>
	/// Set string to text file
	/// </summary>
	/// <param name="fileName"></param>
	/// <param name="textData"></param>
	/// <returns></returns>
	public static string SetTextToFile(string fileName, string textData = null)
	{
		string result = string.Empty;
		string filePath = "../../samples/" + fileName;

		if (!File.Exists(filePath) && !string.IsNullOrEmpty(textData))
		{
			using (StreamWriter streamWriter = File.CreateText(filePath)) 
            {
                streamWriter.WriteLine(textData);
            }
		}
		
		if (File.Exists(filePath))
		{
			File.WriteAllText(filePath, textData);

			using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
			{
				using (StreamReader streamReader = new StreamReader(fileStream))
				{
					result = streamReader.ReadToEnd();
				}
			}
		}

		return result;
	}

	/// <summary>
	/// Set Re-Generate Timestamp
	/// </summary>
	/// <param name="requestData"></param>
	/// <returns></returns>
	public static string SetRegenerateTimestamp(string requestData)
	{
		string result = string.Empty;

		if (string.IsNullOrEmpty(IsValidJson(requestData)))
		{
			JObject objRequest = JObject.Parse(requestData);

			if (objRequest.Property("TIMESTAMP") != null)
			{
				if (objRequest["TIMESTAMP"].ToString() == "")
				{
					objRequest["TIMESTAMP"] = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
				}
			}

			result = objRequest.ToString();
		}

		return result;
	}

	/// <summary>
	/// Get Request HTTP Web post to get response
	/// </summary>
	/// <param name="url"></param>
	/// <param name="param"></param>
	/// <returns></returns>
	public static string GetWebResponse(string url, string param, out string token)
	{
		string result = string.Empty;
		string requestToken = string.Empty;
		string requestParam = string.Empty;

		requestToken = encode.EncryptTdes(param);
		requestParam = "token=" + Uri.EscapeDataString(requestToken);
		token = string.Empty;

		try
		{
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
			WebRequest request = WebRequest.Create(url);
			request.Method = "POST";

            byte[] byteArray = Encoding.UTF8.GetBytes(requestParam);
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = byteArray.Length;

            // Get the request stream.
            Stream dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();

            // Get the response.
            WebResponse response = request.GetResponse();

            // download contents
            if (response.ContentType == "application/force-download")
            {
				string fileName = string.Empty;
				string filePath = string.Empty;
				byte[] resultBinary;
                byte[] buffer = new byte[4096];

				JObject objParam = JObject.Parse(param);

				if (objParam.Property("FILE_NAME") != null)
				{
					fileName = objParam["FILE_NAME"].ToString();
				}
				
				// Open file dialog
				INTERFACE_TESTER.MainForm.OpenSaveFileDialog(fileName, out filePath);

				using (Stream responseStream = response.GetResponseStream())
                {
                    using (MemoryStream memoryStream = new MemoryStream())
                    {
						int i = 0;
						do
						{
							i = responseStream.Read(buffer, 0, buffer.Length);
							memoryStream.Write(buffer, 0, i);

						} while (i != 0);

						resultBinary = memoryStream.ToArray();
						Stream fileStream = new FileStream(filePath, FileMode.Create);
						BinaryWriter binaryWriter = new BinaryWriter(fileStream);

						foreach (var binary in resultBinary)
						{
							binaryWriter.Write(binary);
						}

						binaryWriter.Flush();
						binaryWriter.Close();
						result = "FILE_SIZE: " + File.ReadAllBytes(filePath).Length.ToString();
						token = result;
						fileStream.Close();
					}
                }
			}
            else
            {
                dataStream = response.GetResponseStream();
                StreamReader streamReader = new StreamReader(dataStream);
                result = streamReader.ReadToEnd();
                streamReader.Close();
                dataStream.Close();
                response.Close();
				token = result;
				result = encode.DecryptTdes(token);
            }
		}
		catch (Exception ex)
		{
			result = ex.Message;
			token = result;
		}

		return result;
	}

	/// <summary>
	/// Request HTTP to upload binary file
	/// </summary>
	/// <param name="url"></param>
	/// <param name="file"></param>
	/// <param name="paramName"></param>
	/// <param name="contentType"></param>
	/// <param name="nameValueCollection"></param>
	/// <returns></returns>
	public static string HttpUploadFile(string url, string file, string paramName, string contentType, NameValueCollection nameValueCollection)
	{
		string result = string.Empty;
		string boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x");
		byte[] boundarybytes = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");

		HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(url);
		webRequest.ContentType = "multipart/form-data; boundary=" + boundary;
		webRequest.Method = "POST";
		webRequest.KeepAlive = true;
		webRequest.Credentials = System.Net.CredentialCache.DefaultCredentials;

		Stream responseStream = webRequest.GetRequestStream();

		string formdataTemplate = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";

		foreach (string key in nameValueCollection.Keys)
		{
			responseStream.Write(boundarybytes, 0, boundarybytes.Length);
			string formitem = string.Format(formdataTemplate, key, nameValueCollection[key]);
			byte[] formitembytes = System.Text.Encoding.UTF8.GetBytes(formitem);
			responseStream.Write(formitembytes, 0, formitembytes.Length);
		}

		responseStream.Write(boundarybytes, 0, boundarybytes.Length);

		string headerTemplate = "Content-Disposition: form-data; name=\"{0}\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n";
		string header = string.Format(headerTemplate, paramName, file, contentType);
		byte[] headerbytes = System.Text.Encoding.UTF8.GetBytes(header);

		responseStream.Write(headerbytes, 0, headerbytes.Length);

		FileStream fileStream = new FileStream(file, FileMode.Open, FileAccess.Read);
		byte[] buffer = new byte[4096];
		int bytesRead = 0;

		while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
		{
			responseStream.Write(buffer, 0, bytesRead);
		}

		fileStream.Close();

		byte[] trailer = System.Text.Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
		
		responseStream.Write(trailer, 0, trailer.Length);
		responseStream.Close();

		WebResponse webResponse = webRequest.GetResponse();
		Stream stream2 = webResponse.GetResponseStream();
		StreamReader reader2 = new StreamReader(stream2);

		result = reader2.ReadToEnd();

		return result;
	}

	/// <summary>
	/// Set html basic layout style for result
	/// </summary>
	/// <param name="htmlContent"></param>
	/// <returns></returns>
	public static string SetHtmlHeaderFooter(string htmlContent = null)
	{
		string result = string.Empty;
		string style = string.Empty;

		style = @"
			body {
				margin: 0;
				padding: 0;
				width: 100vw;
				height: 100vh;
				overflow: hidden;
				scrollbar-color: rgb(48, 48, 48);
				word-break: break-all;
				font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
				font-size: 12px;
				color: rgb(220, 220, 220);
				background-color: rgb(48, 48, 48);
			}
			h4, h5, p, pre {
				margin: 0;
				padding: 3px;
			}
			h5 {
				padding: 6px 3px;
			}
			p, pre {
				background-color: rgb(30, 30, 30);
			}
			code {
				margin: 0;
				padding: 0;
				font-family: consolas, 'Courier New', Courier, monospace;
    			line-height: 120%;
				word-wrap: break-word;
				-ms-word-wrap: break-word;
				word-break: break-all;
				-ms-word-break: break-all;
			}
		";

		result += "<!DOCTYPE html>\n"
			+ "<html lang=\"en\">\n"
			+ "<head>\n"
			+ "<meta charset=\"utf-8\">\n"
			+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n"
			+ "<title>Interface Tester: Request</title>\n"
			+ "<style type=\"text/css\">\n"
			+ style + "\n"
			+ "</style>\n"
			+ "</head>\n"
			+ "<body>\n"
			+ htmlContent + "\n"
			+ "</body>\n"
			+ "</html>\n";

		return result;
	}

	/// <summary>
	/// JSON to string text
	/// </summary>
	/// <param name="stringJson"></param>
	/// <returns></returns>
	public static string JsonToString(string stringJson)
	{
		string result = string.Empty;
		
		if (string.IsNullOrEmpty(IsValidJson(stringJson.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ").ToString())))
		{
			JObject objOutputResult = JObject.Parse(stringJson);
			dynamic dynamicOutput = JsonConvert.DeserializeObject(objOutputResult.ToString());

			foreach (var itemOutput in dynamicOutput)
			{
				if ((itemOutput.Value.ToString().StartsWith("{") && itemOutput.Value.ToString().EndsWith("}")) || (itemOutput.Value.ToString().StartsWith("[") && itemOutput.Value.ToString().EndsWith("]")))
				{
					foreach (var itemReturn in itemOutput.Value)
					{
						result += itemOutput.Name + "." + itemReturn.Name + "=\"" + itemReturn.Value.ToString() + "\"\n";
					}
				}
				else
				{
					result += itemOutput.Name + "=\"" + itemOutput.Value.ToString() + "\"\n";
				}
			}
		}

		return result;
	}

	/// <summary>
	/// Get result to HTML
	/// </summary>
	/// <param name="code"></param>
	/// <param name="paragraph"></param>
	/// <returns></returns>
	public static string GetResultHTML(string type, string code, string paragraph)
	{
		string result = string.Empty;

		if (type == "REQ")
		{
			result = "<h4>Request</h4>\n"
				+ "<h5>Before Encrypted</h5>\n"
				+ "<pre><code>" + code + "</code></pre>\n"
				+ "<h5>After Encrypted</h5>\n"
				+ "<p>"+ paragraph + "</p>\n";
		}
		else if (type == "RES")
		{
			result = "<h4>Response</h4>\n"
				+ "<h5>Before Decrypted</h5>\n"
				+ "<p>"+ paragraph + "</p>\n"
				+ "<h5>After Decrypted</h5>\n"
				+ "<pre><code>" + code + "</code></pre>\n";
		}

		return result;
	}

	/// <summary>
	/// Check validate JSON format
	/// </summary>
	/// <param name="jsonString"></param>
	/// <returns></returns>
	public static string IsValidJson(string jsonString)
	{
		string result = string.Empty;
		jsonString = jsonString.Trim();

		if (jsonString.Length > 0)
		{
			if (!jsonString.StartsWith("Error"))
			{
				if ((jsonString.StartsWith("{") && jsonString.EndsWith("}")) || (jsonString.StartsWith("[") && jsonString.EndsWith("]")))
				{
					try
					{
						var obj = JToken.Parse(jsonString);
					}
					catch (JsonReaderException jex)
					{
						result = jex.Message;
					}
					catch (Exception ex)
					{
						result = ex.Message;
					}
				}
				else
				{
					result = "Invalid JSON format";
				}
			}
			else
			{
				result = jsonString;
			}
		}
		else
		{
			result = "Please enter request data.";
		}

		return result;
	}

	/// <summary>
	/// Check validate URL format
	/// </summary>
	/// <param name="url"></param>
	/// <returns></returns>
	public static bool IsValidUrl(string url)
    {
        if (url == null)
        {
            return false;
        }

        try
        {
            Uri uriResult = new Uri(url);
            return Uri.IsWellFormedUriString(url, UriKind.RelativeOrAbsolute);
        }
        catch
        {
            return false;
        }
    }

	/// <summary>
	/// JSON to string text
	/// </summary>
	/// <param name="stringJson"></param>
	/// <returns></returns>
	public static bool ValidateJsonValue(string stringJson)
	{
		bool result = true;
		
		if (string.IsNullOrEmpty(IsValidJson(stringJson.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ").ToString())))
		{
			JObject objOutputResult = JObject.Parse(stringJson);
			dynamic dynamicOutput = JsonConvert.DeserializeObject(objOutputResult.ToString());

			foreach (var itemOutput in dynamicOutput)
			{
				if ((itemOutput.Value.ToString().StartsWith("{") && itemOutput.Value.ToString().EndsWith("}")) || (itemOutput.Value.ToString().StartsWith("[") && itemOutput.Value.ToString().EndsWith("]")))
				{
					foreach (var itemReturn in itemOutput.Value)
					{
						if (itemReturn.Name != "TIMESTAMP" && itemReturn.Value.ToString().StartsWith("∣∣") && itemReturn.Value.ToString().EndsWith("∣∣"))
						{
							result = false;
						}
					}
				}
				else
				{
					if (itemOutput.Name != "TIMESTAMP" && itemOutput.Value.ToString().StartsWith("∣∣") && itemOutput.Value.ToString().EndsWith("∣∣"))
					{
						result = false;
					}
				}
			}
		}

		return result;
	}

	/// <summary>
	/// Load JSON to Tree view node
	/// </summary>
	/// <param name="treeView"></param>
	/// <param name="name"></param>
	/// <param name="json"></param>
	public static void GetJsonToTreeView(TreeView treeView, string name, string json)
    {
        treeView.Visible = true;
        
        if (string.IsNullOrWhiteSpace(json))
        {
            return;
        }

        var @object = JObject.Parse(json);
        AddObjectNodes(@object, name, treeView.Nodes);
    }

	/// <summary>
	/// Add JObject as nodes
	/// </summary>
	/// <param name="@object"></param>
	/// <param name="name"></param>
	/// <param name="parent"></param>
    public static void AddObjectNodes(JObject @object, string name, TreeNodeCollection parent)
    {
        var node = new TreeNode(name);
        parent.Add(node);

        foreach (var property in @object.Properties())
        {
            AddTokenNodes(property.Value, property.Name, node.Nodes);
        }
    }

	/// <summary>
	/// Add JArray as nodes
	/// </summary>
	/// <param name="array"></param>
	/// <param name="name"></param>
	/// <param name="parent"></param>
    private static void AddArrayNodes(JArray array, string name, TreeNodeCollection parent)
    {
        var node = new TreeNode(name);
        parent.Add(node);

        for (var i = 0; i < array.Count; i++)
        {
            AddTokenNodes(array[i], string.Format("[{0}]", i), node.Nodes);
        }
    }

	/// <summary>
	/// Add Jtoken as nodes
	/// </summary>
	/// <param name="token"></param>
	/// <param name="name"></param>
	/// <param name="parent"></param>
    private static void AddTokenNodes(JToken token, string name, TreeNodeCollection parent)
    {
        if (token is JValue)
        {
            parent.Add(new TreeNode(string.Format("{0}: {1}", name, ((JValue)token).Value)));
        }
        else if (token is JArray)
        {
            AddArrayNodes((JArray)token, name, parent);
        }
        else if (token is JObject)
        {
            AddObjectNodes((JObject)token, name, parent);
        }
    }
}