﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace Hyundai.BEL.Utils
{
	public static class EncryptionUtil
	{
		private const string ENCRYPTION_KEY = "Bc7eO7S/yVM";
		private readonly static byte[] SALT = Encoding.ASCII.GetBytes(ENCRYPTION_KEY);
		private readonly static byte[] key;
		private readonly static byte[] iv;
		private static readonly Rfc2898DeriveBytes keyGenerator;

		static EncryptionUtil()
		{
			keyGenerator = new Rfc2898DeriveBytes(ENCRYPTION_KEY, SALT);
			key = keyGenerator.GetBytes(32);
			iv = keyGenerator.GetBytes(16);
		}

		public static string Encrypt(string inputText)
		{
			RijndaelManaged rijndaelCipher = new RijndaelManaged { Key = key, IV = iv };
			byte[] plainText = Encoding.Unicode.GetBytes(inputText);

			using (ICryptoTransform encryptor = rijndaelCipher.CreateEncryptor())
			{
				using (MemoryStream memoryStream = new MemoryStream())
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
					{
						cryptoStream.Write(plainText, 0, plainText.Length);
						cryptoStream.FlushFinalBlock();
						return Convert.ToBase64String(memoryStream.ToArray());
					}
				}
			}
		}

		public static string Decrypt(string inputText)
		{
			RijndaelManaged rijndaelCipher = new RijndaelManaged();
			byte[] encryptedData = Convert.FromBase64String(inputText);

			using (ICryptoTransform decryptor = rijndaelCipher.CreateDecryptor(key, iv))
			{
				using (MemoryStream memoryStream = new MemoryStream(encryptedData))
				{
					using (CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
					{
						byte[] plainText = new byte[encryptedData.Length];
						int decryptedCount = cryptoStream.Read(plainText, 0, plainText.Length);
						return Encoding.Unicode.GetString(plainText, 0, decryptedCount);
					}
				}
			}
		}

	}
}
